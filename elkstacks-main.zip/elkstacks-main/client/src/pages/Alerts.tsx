import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { UIAlert } from "@/types";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { 
  Select, 
  SelectTrigger, 
  SelectValue, 
  SelectContent, 
  SelectItem 
} from "@/components/ui/select";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AlertsResponseData {
  active: UIAlert[];
  acknowledged: UIAlert[];
  resolved: UIAlert[];
  activeCount: number;
  acknowledgedCount: number;
  resolvedCount: number;
}

const Alerts: React.FC = () => {
  const [timeRange, setTimeRange] = useState("24h");
  const [activeTab, setActiveTab] = useState("active");
  const { toast } = useToast();

  // Fetch alerts data
  const { data, isLoading, isError, refetch } = useQuery<AlertsResponseData>({
    queryKey: ['/api/alerts', timeRange, activeTab],
  });

  // Function to handle time range change
  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };

  // Function to handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  // Function to handle refresh button click
  const handleRefresh = () => {
    refetch();
  };

  // Function to acknowledge an alert
  const handleAcknowledge = async (alertId: number) => {
    try {
      await apiRequest("POST", `/api/alerts/${alertId}/acknowledge`, {});
      
      toast({
        title: "Alert acknowledged",
        description: "The alert has been marked as acknowledged.",
      });
      
      // Invalidate and refetch alerts
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to acknowledge the alert. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Function to resolve an alert
  const handleResolve = async (alertId: number) => {
    try {
      await apiRequest("POST", `/api/alerts/${alertId}/resolve`, {});
      
      toast({
        title: "Alert resolved",
        description: "The alert has been marked as resolved.",
      });
      
      // Invalidate and refetch alerts
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to resolve the alert. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Alert Management</h1>
            <p className="mt-1 text-sm text-gray-500">
              Monitor and respond to system and application alerts
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <span className="material-icons text-gray-400 text-sm">schedule</span>
              </div>
              <Select value={timeRange} onValueChange={handleTimeRangeChange}>
                <SelectTrigger className="pl-10 pr-4 py-2">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last hour</SelectItem>
                  <SelectItem value="3h">Last 3 hours</SelectItem>
                  <SelectItem value="12h">Last 12 hours</SelectItem>
                  <SelectItem value="24h">Last 24 hours</SelectItem>
                  <SelectItem value="3d">Last 3 days</SelectItem>
                  <SelectItem value="7d">Last week</SelectItem>
                  <SelectItem value="30d">Last month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleRefresh} className="inline-flex items-center">
              <span className="material-icons text-sm mr-2">refresh</span>
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Alert Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className={activeTab === "active" ? "ring-2 ring-primary" : ""}>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Active Alerts</p>
                <h3 className="mt-1 text-2xl font-semibold text-gray-900">
                  {isLoading ? "..." : data?.activeCount || 0}
                </h3>
              </div>
              <div className="rounded-full bg-status-error bg-opacity-10 p-2">
                <span className="material-icons text-status-error">warning</span>
              </div>
            </div>
            <Button 
              variant="ghost" 
              className="mt-2 p-0 h-auto text-sm text-primary"
              onClick={() => handleTabChange("active")}
            >
              View active alerts
            </Button>
          </CardContent>
        </Card>
        
        <Card className={activeTab === "acknowledged" ? "ring-2 ring-primary" : ""}>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Acknowledged</p>
                <h3 className="mt-1 text-2xl font-semibold text-gray-900">
                  {isLoading ? "..." : data?.acknowledgedCount || 0}
                </h3>
              </div>
              <div className="rounded-full bg-status-warning bg-opacity-10 p-2">
                <span className="material-icons text-status-warning">hourglass_top</span>
              </div>
            </div>
            <Button 
              variant="ghost" 
              className="mt-2 p-0 h-auto text-sm text-primary"
              onClick={() => handleTabChange("acknowledged")}
            >
              View acknowledged alerts
            </Button>
          </CardContent>
        </Card>
        
        <Card className={activeTab === "resolved" ? "ring-2 ring-primary" : ""}>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-500">Resolved</p>
                <h3 className="mt-1 text-2xl font-semibold text-gray-900">
                  {isLoading ? "..." : data?.resolvedCount || 0}
                </h3>
              </div>
              <div className="rounded-full bg-status-success bg-opacity-10 p-2">
                <span className="material-icons text-status-success">check_circle</span>
              </div>
            </div>
            <Button 
              variant="ghost" 
              className="mt-2 p-0 h-auto text-sm text-primary"
              onClick={() => handleTabChange("resolved")}
            >
              View resolved alerts
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Alerts Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="active">
            Active
            {data?.activeCount ? (
              <Badge className="ml-2 bg-status-error" variant="secondary">
                {data.activeCount}
              </Badge>
            ) : null}
          </TabsTrigger>
          <TabsTrigger value="acknowledged">
            Acknowledged
            {data?.acknowledgedCount ? (
              <Badge className="ml-2 bg-status-warning" variant="secondary">
                {data.acknowledgedCount}
              </Badge>
            ) : null}
          </TabsTrigger>
          <TabsTrigger value="resolved">Resolved</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Active Alerts</CardTitle>
              <CardDescription>
                Alerts that require immediate attention
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                // Loading state
                <div className="animate-pulse space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="h-24 bg-gray-200 rounded"></div>
                  ))}
                </div>
              ) : isError ? (
                // Error state
                <div className="p-4 text-center text-gray-500">
                  <span className="material-icons text-status-error mb-2 text-4xl">error</span>
                  <p>Failed to load alerts. Please try again later.</p>
                  <Button onClick={handleRefresh} className="mt-3">
                    Retry
                  </Button>
                </div>
              ) : data?.active.length ? (
                // Alert list
                <div className="space-y-3">
                  {data.active.map((alert, index) => (
                    <div 
                      key={index} 
                      className={`p-4 border-l-4 ${alert.colorClass} rounded-md ${
                        alert.level === 'error' ? 'bg-red-50' : 
                        alert.level === 'warning' ? 'bg-yellow-50' : 
                        'bg-blue-50'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className={`material-icons ${
                              alert.level === 'error' ? 'text-status-error' : 
                              alert.level === 'warning' ? 'text-status-warning' : 
                              'text-secondary'
                            }`}>
                              {alert.level === 'error' ? 'error' : 
                               alert.level === 'warning' ? 'warning' : 
                               'info'}
                            </span>
                            <h3 className={`text-sm font-medium ${
                              alert.level === 'error' ? 'text-status-error' : 
                              alert.level === 'warning' ? 'text-status-warning' : 
                              'text-secondary'
                            }`}>
                              {alert.level === 'error' ? 'Critical: ' : 
                               alert.level === 'warning' ? 'Warning: ' : 'Info: '}
                              {alert.source}
                            </h3>
                          </div>
                          <p className="mt-1 text-sm text-gray-700">{alert.message}</p>
                          <div className="mt-1 text-xs text-gray-500">
                            Reported {alert.timeAgo} (#{alert.id})
                          </div>
                        </div>
                        <div className="flex md:flex-col gap-2 md:min-w-[120px]">
                          <Button 
                            size="sm" 
                            onClick={() => handleAcknowledge(alert.id)}
                          >
                            Acknowledge
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleResolve(alert.id)}
                          >
                            Resolve
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                // Empty state
                <div className="p-8 text-center text-gray-500">
                  <span className="material-icons text-gray-400 mb-2 text-4xl">check_circle</span>
                  <p>No active alerts at this time.</p>
                  <p className="text-sm mt-1">All systems are operating normally.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="acknowledged">
          <Card>
            <CardHeader>
              <CardTitle>Acknowledged Alerts</CardTitle>
              <CardDescription>
                Alerts that have been seen but not yet resolved
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                // Loading state
                <div className="animate-pulse space-y-4">
                  {Array.from({ length: 2 }).map((_, i) => (
                    <div key={i} className="h-24 bg-gray-200 rounded"></div>
                  ))}
                </div>
              ) : isError ? (
                // Error state
                <div className="p-4 text-center text-gray-500">
                  <span className="material-icons text-status-error mb-2 text-4xl">error</span>
                  <p>Failed to load alerts. Please try again later.</p>
                  <Button onClick={handleRefresh} className="mt-3">
                    Retry
                  </Button>
                </div>
              ) : data?.acknowledged.length ? (
                // Alert list
                <div className="space-y-3">
                  {data.acknowledged.map((alert, index) => (
                    <div 
                      key={index} 
                      className={`p-4 border-l-4 ${alert.colorClass} rounded-md ${
                        alert.level === 'error' ? 'bg-red-50' : 
                        alert.level === 'warning' ? 'bg-yellow-50' : 
                        'bg-blue-50'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className={`material-icons ${
                              alert.level === 'error' ? 'text-status-error' : 
                              alert.level === 'warning' ? 'text-status-warning' : 
                              'text-secondary'
                            }`}>
                              {alert.level === 'error' ? 'error' : 
                               alert.level === 'warning' ? 'warning' : 
                               'info'}
                            </span>
                            <h3 className={`text-sm font-medium ${
                              alert.level === 'error' ? 'text-status-error' : 
                              alert.level === 'warning' ? 'text-status-warning' : 
                              'text-secondary'
                            }`}>
                              {alert.level === 'error' ? 'Critical: ' : 
                               alert.level === 'warning' ? 'Warning: ' : 'Info: '}
                              {alert.source}
                            </h3>
                          </div>
                          <p className="mt-1 text-sm text-gray-700">{alert.message}</p>
                          <div className="mt-1 text-xs text-gray-500">
                            Reported {alert.timeAgo} (#{alert.id})
                          </div>
                        </div>
                        <div>
                          <Button 
                            size="sm" 
                            onClick={() => handleResolve(alert.id)}
                          >
                            Resolve
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                // Empty state
                <div className="p-8 text-center text-gray-500">
                  <span className="material-icons text-gray-400 mb-2 text-4xl">notifications_none</span>
                  <p>No acknowledged alerts.</p>
                  <p className="text-sm mt-1">All alerts are either active or resolved.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="resolved">
          <Card>
            <CardHeader>
              <CardTitle>Resolved Alerts</CardTitle>
              <CardDescription>
                Alerts that have been fixed
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                // Loading state
                <div className="animate-pulse space-y-4">
                  {Array.from({ length: 2 }).map((_, i) => (
                    <div key={i} className="h-24 bg-gray-200 rounded"></div>
                  ))}
                </div>
              ) : isError ? (
                // Error state
                <div className="p-4 text-center text-gray-500">
                  <span className="material-icons text-status-error mb-2 text-4xl">error</span>
                  <p>Failed to load alerts. Please try again later.</p>
                  <Button onClick={handleRefresh} className="mt-3">
                    Retry
                  </Button>
                </div>
              ) : data?.resolved.length ? (
                // Alert list
                <div className="space-y-3">
                  {data.resolved.map((alert, index) => (
                    <div 
                      key={index} 
                      className="p-4 border border-gray-200 rounded-md bg-gray-50"
                    >
                      <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="material-icons text-status-success">check_circle</span>
                            <h3 className="text-sm font-medium text-gray-700">
                              {alert.source}
                            </h3>
                          </div>
                          <p className="mt-1 text-sm text-gray-700">{alert.message}</p>
                          <div className="mt-1 text-xs text-gray-500">
                            Resolved {alert.timeAgo} (#{alert.id})
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                // Empty state
                <div className="p-8 text-center text-gray-500">
                  <span className="material-icons text-gray-400 mb-2 text-4xl">history</span>
                  <p>No resolved alerts in the selected time period.</p>
                  <p className="text-sm mt-1">Try extending the time range to see historical alerts.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Alert Rules Section */}
      <Card>
        <CardHeader>
          <CardTitle>Alert Rules</CardTitle>
          <CardDescription>
            Configure when and how alerts are triggered
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <p className="text-sm text-gray-600">
                You have 12 alert rules configured across different systems.
              </p>
              <p className="text-sm text-gray-600">
                Last updated: 3 days ago
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">
                <span className="material-icons text-sm mr-2">edit</span>
                Manage Rules
              </Button>
              <Button>
                <span className="material-icons text-sm mr-2">add</span>
                New Rule
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
};

export default Alerts;
