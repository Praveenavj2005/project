import React from "react";
import { useQuery } from "@tanstack/react-query";
import { StatusCard } from "@/components/dashboard/StatusCard";
import { MetricsPanel } from "@/components/dashboard/MetricsPanel";
import { LogsPanel } from "@/components/dashboard/LogsPanel";
import { AlertsPanel } from "@/components/dashboard/AlertsPanel";
import { HostsPanel } from "@/components/dashboard/HostsPanel";
import { SystemHealthPanel } from "@/components/dashboard/SystemHealthPanel";
import { 
  DashboardData,
  SystemStatus,
  CpuStatus,
  MemoryStatus,
  AlertsStatus
} from "@/types";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

const Dashboard: React.FC = () => {
  const [timeRange, setTimeRange] = React.useState("24h");

  // Fetch dashboard data
  const { data, isLoading, isError, refetch } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard', timeRange],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Function to handle refresh button click
  const handleRefresh = () => {
    refetch();
  };

  // Function to handle time range change
  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="mb-6">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-2/4"></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
        <div className="h-96 bg-gray-200 rounded-lg mb-6"></div>
      </div>
    );
  }

  // Error state
  if (isError || !data) {
    return (
      <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
        <div className="flex items-start">
          <span className="material-icons text-red-500 mr-3">error</span>
          <div>
            <h3 className="text-red-500 font-medium">Error loading dashboard data</h3>
            <p className="text-sm text-gray-700 mt-1">
              There was a problem loading dashboard data. Please try refreshing the page or contact support.
            </p>
            <Button 
              onClick={handleRefresh} 
              className="mt-3"
            >
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const {
    systemStatus,
    cpuStatus,
    memoryStatus,
    alertsStatus,
    recentLogs,
    activeAlerts,
    hosts,
    services,
    metrics
  } = data;

  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">System Dashboard</h1>
            <p className="mt-1 text-sm text-gray-500">Overview of system health and performance</p>
          </div>
          <div className="mt-4 md:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <span className="material-icons text-gray-400 text-sm">schedule</span>
              </div>
              <Select value={timeRange} onValueChange={handleTimeRangeChange}>
                <SelectTrigger className="pl-10 pr-4 py-2">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last hour</SelectItem>
                  <SelectItem value="3h">Last 3 hours</SelectItem>
                  <SelectItem value="12h">Last 12 hours</SelectItem>
                  <SelectItem value="24h">Last 24 hours</SelectItem>
                  <SelectItem value="3d">Last 3 days</SelectItem>
                  <SelectItem value="7d">Last week</SelectItem>
                  <SelectItem value="30d">Last month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleRefresh} className="inline-flex items-center">
              <span className="material-icons text-sm mr-2">refresh</span>
              Refresh
            </Button>
          </div>
        </div>
      </div>
      
      {/* System Status Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatusCard
          title="System Status"
          value={systemStatus.status === 'success' ? 'Healthy' : systemStatus.status === 'warning' ? 'Degraded' : 'Critical'}
          icon={systemStatus.status === 'success' ? 'check_circle' : systemStatus.status === 'warning' ? 'info' : 'error'}
          status={systemStatus.status}
          description={`Last checked: ${systemStatus.lastChecked}`}
        />
        
        <StatusCard
          title="CPU Load"
          value={`${cpuStatus.usage}%`}
          icon="memory"
          status={cpuStatus.status}
          description={cpuStatus.message}
        />
        
        <StatusCard
          title="Memory Usage"
          value={`${memoryStatus.usage}%`}
          icon="sd_card"
          status={memoryStatus.status}
          description={`${memoryStatus.used}GB / ${memoryStatus.total}GB`}
        />
        
        <StatusCard
          title="Alerts"
          value={`${alertsStatus.count} Active`}
          icon="warning"
          status={alertsStatus.status}
          description={alertsStatus.latestMessage}
        />
      </div>
      
      {/* Metrics & Logs Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MetricsPanel 
            cpuData={metrics.cpu}
            memoryData={metrics.memory}
            diskData={metrics.disk}
            networkData={metrics.network}
            cpuUsage={cpuStatus.usage}
            memoryUsage={memoryStatus.usage}
            diskIORate="24 MB/s"
            networkRate="5.2 MB/s"
          />
          <LogsPanel logs={recentLogs} />
        </div>
        
        <div className="lg:col-span-1">
          <AlertsPanel alerts={activeAlerts} />
          <HostsPanel hosts={hosts} />
          <SystemHealthPanel services={services} />
        </div>
      </div>
    </>
  );
};

export default Dashboard;
