import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { LogEntry } from "@/components/logs/LogEntry";
import { UILog } from "@/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  Select, 
  SelectTrigger, 
  SelectValue, 
  SelectContent, 
  SelectItem 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";

interface LogsResponseData {
  logs: UILog[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

const Logs: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [levelFilter, setLevelFilter] = useState("all");
  const [sourceFilter, setSourceFilter] = useState("all");
  const [timeRange, setTimeRange] = useState("24h");
  const [page, setPage] = useState(1);
  const [debouncedSearch, setDebouncedSearch] = useState("");

  // Debounce search term to avoid too many requests
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm);
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm]);

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, levelFilter, sourceFilter, timeRange]);

  // Fetch logs data
  const { data, isLoading, isError, refetch } = useQuery<LogsResponseData>({
    queryKey: [
      '/api/logs', 
      debouncedSearch, 
      levelFilter, 
      sourceFilter, 
      timeRange, 
      page
    ],
  });

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle level filter change
  const handleLevelFilterChange = (value: string) => {
    setLevelFilter(value);
  };

  // Handle source filter change
  const handleSourceFilterChange = (value: string) => {
    setSourceFilter(value);
  };

  // Handle time range change
  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };

  // Handle page change
  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  // Function to handle refresh button click
  const handleRefresh = () => {
    refetch();
  };

  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Log Explorer</h1>
            <p className="mt-1 text-sm text-gray-500">
              Search and analyze system and application logs
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <span className="material-icons text-gray-400 text-sm">schedule</span>
              </div>
              <Select value={timeRange} onValueChange={handleTimeRangeChange}>
                <SelectTrigger className="pl-10 pr-4 py-2">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last hour</SelectItem>
                  <SelectItem value="3h">Last 3 hours</SelectItem>
                  <SelectItem value="12h">Last 12 hours</SelectItem>
                  <SelectItem value="24h">Last 24 hours</SelectItem>
                  <SelectItem value="3d">Last 3 days</SelectItem>
                  <SelectItem value="7d">Last week</SelectItem>
                  <SelectItem value="30d">Last month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleRefresh} className="inline-flex items-center">
              <span className="material-icons text-sm mr-2">refresh</span>
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
          <CardDescription>
            Narrow down logs by searching and applying filters
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <span className="material-icons text-gray-400 text-sm">search</span>
                </div>
                <Input
                  type="text"
                  placeholder="Search logs..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={handleSearchChange}
                />
              </div>
            </div>
            <div>
              <Select value={levelFilter} onValueChange={handleLevelFilterChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Log Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Select value={sourceFilter} onValueChange={handleSourceFilterChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  <SelectItem value="app-server">App Server</SelectItem>
                  <SelectItem value="db-server">DB Server</SelectItem>
                  <SelectItem value="api-gateway">API Gateway</SelectItem>
                  <SelectItem value="elasticsearch">Elasticsearch</SelectItem>
                  <SelectItem value="logstash">Logstash</SelectItem>
                  <SelectItem value="kibana">Kibana</SelectItem>
                  <SelectItem value="prometheus">Prometheus</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Log Results */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:justify-between md:items-center">
            <CardTitle>Log Results</CardTitle>
            {data && (
              <div className="text-sm text-gray-500">
                Showing {(page - 1) * data.pageSize + 1} - {Math.min(page * data.pageSize, data.totalCount)} of {data.totalCount} logs
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            // Loading state
            <div className="animate-pulse space-y-2">
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="h-14 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : isError ? (
            // Error state
            <div className="p-4 text-center text-gray-500">
              <span className="material-icons text-status-error mb-2 text-4xl">error</span>
              <p>Failed to load logs. Please try again later.</p>
              <Button onClick={handleRefresh} className="mt-3">
                Retry
              </Button>
            </div>
          ) : data && data.logs.length > 0 ? (
            // Logs display
            <div className="border rounded-md overflow-hidden">
              {data.logs.map((log, index) => (
                <LogEntry key={index} log={log} />
              ))}
            </div>
          ) : (
            // Empty state
            <div className="p-8 text-center text-gray-500">
              <span className="material-icons text-gray-400 mb-2 text-4xl">search_off</span>
              <p>No logs found matching your criteria.</p>
              <p className="text-sm mt-1">Try adjusting your filters or search term.</p>
            </div>
          )}

          {/* Pagination */}
          {data && data.totalPages > 1 && (
            <Pagination className="mt-4">
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (page > 1) handlePageChange(page - 1);
                    }}
                    className={page === 1 ? "pointer-events-none opacity-50" : ""}
                  />
                </PaginationItem>
                
                {/* First page */}
                {page > 2 && (
                  <PaginationItem>
                    <PaginationLink 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        handlePageChange(1);
                      }}
                    >
                      1
                    </PaginationLink>
                  </PaginationItem>
                )}
                
                {/* Ellipsis if needed */}
                {page > 3 && (
                  <PaginationItem>
                    <span className="px-2">...</span>
                  </PaginationItem>
                )}
                
                {/* Previous page if not first */}
                {page > 1 && (
                  <PaginationItem>
                    <PaginationLink 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        handlePageChange(page - 1);
                      }}
                    >
                      {page - 1}
                    </PaginationLink>
                  </PaginationItem>
                )}
                
                {/* Current page */}
                <PaginationItem>
                  <PaginationLink 
                    href="#" 
                    onClick={(e) => e.preventDefault()} 
                    isActive
                  >
                    {page}
                  </PaginationLink>
                </PaginationItem>
                
                {/* Next page if not last */}
                {page < data.totalPages && (
                  <PaginationItem>
                    <PaginationLink 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        handlePageChange(page + 1);
                      }}
                    >
                      {page + 1}
                    </PaginationLink>
                  </PaginationItem>
                )}
                
                {/* Ellipsis if needed */}
                {page < data.totalPages - 2 && (
                  <PaginationItem>
                    <span className="px-2">...</span>
                  </PaginationItem>
                )}
                
                {/* Last page if not current or next */}
                {page < data.totalPages - 1 && (
                  <PaginationItem>
                    <PaginationLink 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        handlePageChange(data.totalPages);
                      }}
                    >
                      {data.totalPages}
                    </PaginationLink>
                  </PaginationItem>
                )}
                
                <PaginationItem>
                  <PaginationNext 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (page < data.totalPages) handlePageChange(page + 1);
                    }}
                    className={page === data.totalPages ? "pointer-events-none opacity-50" : ""}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default Logs;
