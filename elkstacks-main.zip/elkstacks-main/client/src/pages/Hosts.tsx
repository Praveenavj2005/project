import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { UIHost } from "@/types";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectTrigger, 
  SelectValue, 
  SelectContent, 
  SelectItem 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Chart } from "@/components/ui/chart";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface HostResponseData {
  hosts: UIHost[];
  metrics: {
    [hostId: string]: {
      cpu: {
        data: any;
        current: number;
      };
      memory: {
        data: any;
        current: number;
      };
      disk: {
        data: any;
        current: number;
      };
    };
  };
}

const Hosts: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedHostId, setSelectedHostId] = useState<number | null>(null);
  
  // Fetch hosts data
  const { data, isLoading, isError, refetch } = useQuery<HostResponseData>({
    queryKey: ['/api/hosts', searchTerm, statusFilter],
  });
  
  // Filter hosts based on search and status filter
  const filteredHosts = React.useMemo(() => {
    if (!data || !data.hosts) return [];
    
    return data.hosts.filter(host => {
      const matchesSearch = 
        host.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        host.ip.toLowerCase().includes(searchTerm.toLowerCase());
        
      const matchesStatus = statusFilter === 'all' || host.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [data, searchTerm, statusFilter]);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle status filter change
  const handleStatusFilterChange = (value: string) => {
    setStatusFilter(value);
  };

  // Handle host selection for detailed view
  const handleSelectHost = (hostId: number) => {
    setSelectedHostId(hostId === selectedHostId ? null : hostId);
  };

  // Function to handle refresh button click
  const handleRefresh = () => {
    refetch();
  };

  // Get status color based on host status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'bg-status-success';
      case 'warning':
        return 'bg-status-warning';
      case 'error':
        return 'bg-status-error';
      default:
        return 'bg-status-inactive';
    }
  };

  // Get status text based on host status
  const getStatusText = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'Healthy';
      case 'warning':
        return 'Warning';
      case 'error':
        return 'Error';
      default:
        return 'Inactive';
    }
  };

  // Selected host details
  const selectedHost = selectedHostId 
    ? filteredHosts.find(host => host.id === selectedHostId) 
    : null;
    
  const selectedHostMetrics = selectedHostId && data?.metrics 
    ? data.metrics[selectedHostId] 
    : null;

  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Hosts Management</h1>
            <p className="mt-1 text-sm text-gray-500">
              Monitor and manage system hosts
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={handleRefresh} className="inline-flex items-center">
              <span className="material-icons text-sm mr-2">refresh</span>
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-3">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <span className="material-icons text-gray-400 text-sm">search</span>
                </div>
                <Input
                  type="text"
                  placeholder="Search hosts by name or IP..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={handleSearchChange}
                />
              </div>
            </div>
            <div>
              <Select value={statusFilter} onValueChange={handleStatusFilterChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="healthy">Healthy</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hosts List and Details View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hosts List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Hosts</CardTitle>
              <CardDescription>
                {filteredHosts.length} hosts found
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                // Loading state
                <div className="animate-pulse space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="h-12 bg-gray-200 rounded"></div>
                  ))}
                </div>
              ) : isError ? (
                // Error state
                <div className="p-4 text-center text-gray-500">
                  <span className="material-icons text-status-error mb-2 text-4xl">error</span>
                  <p>Failed to load hosts. Please try again later.</p>
                  <Button onClick={handleRefresh} className="mt-3">
                    Retry
                  </Button>
                </div>
              ) : filteredHosts.length > 0 ? (
                // Hosts list
                <div className="space-y-2">
                  {filteredHosts.map((host) => (
                    <div
                      key={host.id}
                      className={`p-3 border rounded-md cursor-pointer transition-colors ${
                        selectedHostId === host.id
                          ? 'border-primary bg-primary bg-opacity-5'
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => handleSelectHost(host.id)}
                    >
                      <div className="flex items-center">
                        <span
                          className={`w-3 h-3 ${getStatusColor(host.status)} rounded-full mr-3`}
                          aria-hidden="true"
                        ></span>
                        <div>
                          <h3 className="text-sm font-medium text-gray-900">{host.name}</h3>
                          <p className="text-xs text-gray-500">{host.ip}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                // Empty state
                <div className="p-8 text-center text-gray-500">
                  <span className="material-icons text-gray-400 mb-2 text-4xl">devices</span>
                  <p>No hosts found matching your criteria.</p>
                  <p className="text-sm mt-1">Try adjusting your filters or search term.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Host Details */}
        <div className="lg:col-span-2">
          {selectedHost ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-3 h-3 ${getStatusColor(selectedHost.status)} rounded-full`}
                        aria-hidden="true"
                      ></span>
                      <CardTitle>{selectedHost.name}</CardTitle>
                    </div>
                    <CardDescription>
                      IP: {selectedHost.ip} | Status: {getStatusText(selectedHost.status)}
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <span className="material-icons text-sm mr-2">settings</span>
                      Configure
                    </Button>
                    <Button variant="outline" size="sm">
                      <span className="material-icons text-sm mr-2">refresh</span>
                      Restart
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview">
                  <TabsList className="mb-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="metrics">Metrics</TabsTrigger>
                    <TabsTrigger value="logs">Logs</TabsTrigger>
                    <TabsTrigger value="services">Services</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview">
                    {/* System Overview */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-500">CPU Usage</p>
                            <h3 className="mt-1 text-xl font-semibold text-gray-900">
                              {selectedHostMetrics?.cpu?.current || 0}%
                            </h3>
                          </div>
                          <div className={`rounded-full bg-status-${
                            (selectedHostMetrics?.cpu?.current || 0) > 80 ? 'error' : 
                            (selectedHostMetrics?.cpu?.current || 0) > 60 ? 'warning' : 'success'
                          } bg-opacity-10 p-2`}>
                            <span className={`material-icons text-status-${
                              (selectedHostMetrics?.cpu?.current || 0) > 80 ? 'error' : 
                              (selectedHostMetrics?.cpu?.current || 0) > 60 ? 'warning' : 'success'
                            }`}>memory</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-500">Memory Usage</p>
                            <h3 className="mt-1 text-xl font-semibold text-gray-900">
                              {selectedHostMetrics?.memory?.current || 0}%
                            </h3>
                          </div>
                          <div className={`rounded-full bg-status-${
                            (selectedHostMetrics?.memory?.current || 0) > 80 ? 'error' : 
                            (selectedHostMetrics?.memory?.current || 0) > 60 ? 'warning' : 'success'
                          } bg-opacity-10 p-2`}>
                            <span className={`material-icons text-status-${
                              (selectedHostMetrics?.memory?.current || 0) > 80 ? 'error' : 
                              (selectedHostMetrics?.memory?.current || 0) > 60 ? 'warning' : 'success'
                            }`}>sd_card</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-500">Disk Usage</p>
                            <h3 className="mt-1 text-xl font-semibold text-gray-900">
                              {selectedHostMetrics?.disk?.current || 0}%
                            </h3>
                          </div>
                          <div className={`rounded-full bg-status-${
                            (selectedHostMetrics?.disk?.current || 0) > 80 ? 'error' : 
                            (selectedHostMetrics?.disk?.current || 0) > 60 ? 'warning' : 'success'
                          } bg-opacity-10 p-2`}>
                            <span className={`material-icons text-status-${
                              (selectedHostMetrics?.disk?.current || 0) > 80 ? 'error' : 
                              (selectedHostMetrics?.disk?.current || 0) > 60 ? 'warning' : 'success'
                            }`}>storage</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* System Information */}
                    <div className="bg-white rounded-lg border mb-6">
                      <div className="p-4 border-b">
                        <h3 className="text-md font-medium">System Information</h3>
                      </div>
                      <div className="p-4">
                        <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
                          {selectedHost.metadata && typeof selectedHost.metadata === 'object' && (
                            <>
                              {Object.entries(selectedHost.metadata as Record<string, any>).map(([key, value]) => (
                                <div key={key} className="flex flex-col">
                                  <dt className="text-sm font-medium text-gray-500">{key}</dt>
                                  <dd className="mt-1 text-sm text-gray-900">{String(value)}</dd>
                                </div>
                              ))}
                            </>
                          )}
                        </dl>
                      </div>
                    </div>
                    
                    {/* Last 5 Events */}
                    <div className="bg-white rounded-lg border">
                      <div className="p-4 border-b">
                        <h3 className="text-md font-medium">Recent Events</h3>
                      </div>
                      <div className="p-4">
                        <div className="text-center text-gray-500 py-8">
                          <span className="material-icons text-gray-400 mb-2 text-4xl">history</span>
                          <p>No recent events for this host.</p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="metrics">
                    <div className="space-y-6">
                      {/* CPU Metrics */}
                      <div className="bg-white rounded-lg border">
                        <div className="p-4 border-b">
                          <h3 className="text-md font-medium">CPU Metrics</h3>
                        </div>
                        <div className="p-4">
                          {selectedHostMetrics?.cpu?.data ? (
                            <Chart
                              data={selectedHostMetrics.cpu.data}
                              height={250}
                            />
                          ) : (
                            <div className="text-center text-gray-500 py-8">
                              <p>No CPU metrics available.</p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Memory Metrics */}
                      <div className="bg-white rounded-lg border">
                        <div className="p-4 border-b">
                          <h3 className="text-md font-medium">Memory Metrics</h3>
                        </div>
                        <div className="p-4">
                          {selectedHostMetrics?.memory?.data ? (
                            <Chart
                              data={selectedHostMetrics.memory.data}
                              height={250}
                            />
                          ) : (
                            <div className="text-center text-gray-500 py-8">
                              <p>No memory metrics available.</p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Disk Metrics */}
                      <div className="bg-white rounded-lg border">
                        <div className="p-4 border-b">
                          <h3 className="text-md font-medium">Disk Metrics</h3>
                        </div>
                        <div className="p-4">
                          {selectedHostMetrics?.disk?.data ? (
                            <Chart
                              data={selectedHostMetrics.disk.data}
                              height={250}
                            />
                          ) : (
                            <div className="text-center text-gray-500 py-8">
                              <p>No disk metrics available.</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="logs">
                    <div className="bg-white rounded-lg border">
                      <div className="p-4 border-b flex justify-between items-center">
                        <h3 className="text-md font-medium">Host Logs</h3>
                        <Button variant="outline" size="sm">
                          <span className="material-icons text-sm mr-2">filter_list</span>
                          Filter
                        </Button>
                      </div>
                      <div className="p-4">
                        <div className="text-center text-gray-500 py-8">
                          <span className="material-icons text-gray-400 mb-2 text-4xl">subject</span>
                          <p>No logs available for this host in the selected time period.</p>
                          <Button variant="outline" className="mt-4">
                            View All Logs
                          </Button>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="services">
                    <div className="bg-white rounded-lg border">
                      <div className="p-4 border-b">
                        <h3 className="text-md font-medium">Running Services</h3>
                      </div>
                      <div className="p-4">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Service</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Port</TableHead>
                              <TableHead>Uptime</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            <TableRow>
                              <TableCell className="font-medium">nginx</TableCell>
                              <TableCell>
                                <span className="inline-flex items-center">
                                  <span className="w-2 h-2 bg-status-success rounded-full mr-2"></span>
                                  Running
                                </span>
                              </TableCell>
                              <TableCell>80, 443</TableCell>
                              <TableCell>2d 14h 23m</TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm">
                                  <span className="material-icons text-sm">more_vert</span>
                                </Button>
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">elasticsearch</TableCell>
                              <TableCell>
                                <span className="inline-flex items-center">
                                  <span className="w-2 h-2 bg-status-success rounded-full mr-2"></span>
                                  Running
                                </span>
                              </TableCell>
                              <TableCell>9200, 9300</TableCell>
                              <TableCell>2d 14h 15m</TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm">
                                  <span className="material-icons text-sm">more_vert</span>
                                </Button>
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">logstash</TableCell>
                              <TableCell>
                                <span className="inline-flex items-center">
                                  <span className="w-2 h-2 bg-status-warning rounded-full mr-2"></span>
                                  Degraded
                                </span>
                              </TableCell>
                              <TableCell>5044</TableCell>
                              <TableCell>2d 10h 42m</TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm">
                                  <span className="material-icons text-sm">more_vert</span>
                                </Button>
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            // No host selected state
            <div className="h-full flex items-center justify-center bg-white rounded-lg border p-8">
              <div className="text-center">
                <span className="material-icons text-gray-400 text-5xl mb-3">
                  device_hub
                </span>
                <h3 className="text-xl font-medium text-gray-900 mb-2">
                  Select a Host
                </h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  Choose a host from the list to view detailed information, metrics, and logs.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Hosts;
