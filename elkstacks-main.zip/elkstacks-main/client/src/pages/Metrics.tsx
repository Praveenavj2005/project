import React from "react";
import { useQuery } from "@tanstack/react-query";
import { MetricChart } from "@/components/metrics/MetricChart";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ChartData } from "@/types";

interface MetricsPageData {
  cpu: {
    utilization: ChartData;
    temperature: ChartData;
    loadAverage: ChartData;
    cores: ChartData;
  };
  memory: {
    usage: ChartData;
    swap: ChartData;
    allocated: ChartData;
  };
  disk: {
    usage: ChartData;
    iops: ChartData;
    throughput: ChartData;
  };
  network: {
    traffic: ChartData;
    packets: ChartData;
    errors: ChartData;
  };
  application: {
    responseTime: ChartData;
    throughput: ChartData;
    errorRate: ChartData;
  };
}

const Metrics: React.FC = () => {
  const [timeRange, setTimeRange] = React.useState("24h");
  const [activeTab, setActiveTab] = React.useState("system");

  // Fetch metrics data
  const { data, isLoading, isError, refetch } = useQuery<MetricsPageData>({
    queryKey: ['/api/metrics', timeRange, activeTab],
  });

  // Function to handle time range change
  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };

  // Function to handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  // Function to handle refresh button click
  const handleRefresh = () => {
    refetch();
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="mb-6">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-2/4"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-[250px] bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  // Error state
  if (isError || !data) {
    return (
      <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
        <div className="flex items-start">
          <span className="material-icons text-red-500 mr-3">error</span>
          <div>
            <h3 className="text-red-500 font-medium">Error loading metrics data</h3>
            <p className="text-sm text-gray-700 mt-1">
              There was a problem loading metrics data. Please try refreshing the page or contact support.
            </p>
            <Button 
              onClick={handleRefresh} 
              className="mt-3"
            >
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">System Metrics</h1>
            <p className="mt-1 text-sm text-gray-500">Detailed performance metrics and trends</p>
          </div>
          <div className="mt-4 md:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <span className="material-icons text-gray-400 text-sm">schedule</span>
              </div>
              <Select value={timeRange} onValueChange={handleTimeRangeChange}>
                <SelectTrigger className="pl-10 pr-4 py-2">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last hour</SelectItem>
                  <SelectItem value="3h">Last 3 hours</SelectItem>
                  <SelectItem value="12h">Last 12 hours</SelectItem>
                  <SelectItem value="24h">Last 24 hours</SelectItem>
                  <SelectItem value="3d">Last 3 days</SelectItem>
                  <SelectItem value="7d">Last week</SelectItem>
                  <SelectItem value="30d">Last month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleRefresh} className="inline-flex items-center">
              <span className="material-icons text-sm mr-2">refresh</span>
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Metrics Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="system">System</TabsTrigger>
          <TabsTrigger value="application">Application</TabsTrigger>
          <TabsTrigger value="custom">Custom</TabsTrigger>
        </TabsList>
        
        <TabsContent value="system">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>CPU Metrics</CardTitle>
                <CardDescription>Overall CPU performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <MetricChart
                    title="CPU Utilization"
                    value="78%"
                    status="warning"
                    data={data.cpu.utilization}
                  />
                  <MetricChart
                    title="CPU Temperature"
                    value="65°C"
                    status="success"
                    data={data.cpu.temperature}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Memory Metrics</CardTitle>
                <CardDescription>RAM and swap usage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <MetricChart
                    title="Memory Usage"
                    value="42%"
                    status="success"
                    data={data.memory.usage}
                  />
                  <MetricChart
                    title="Swap Usage"
                    value="12%"
                    status="success"
                    data={data.memory.swap}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Disk Metrics</CardTitle>
                <CardDescription>Storage performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <MetricChart
                    title="Disk Usage"
                    value="68%"
                    status="success"
                    data={data.disk.usage}
                  />
                  <MetricChart
                    title="Disk I/O"
                    value="24 MB/s"
                    data={data.disk.throughput}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Network Metrics</CardTitle>
                <CardDescription>Network traffic and performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <MetricChart
                    title="Network Traffic"
                    value="5.2 MB/s"
                    data={data.network.traffic}
                  />
                  <MetricChart
                    title="Network Errors"
                    value="0.05%"
                    status="success"
                    data={data.network.errors}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="application">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Application Performance</CardTitle>
                <CardDescription>Response times and throughput</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <MetricChart
                    title="Response Time"
                    value="145 ms"
                    status="success"
                    data={data.application?.responseTime || { labels: [], datasets: [] }}
                  />
                  <MetricChart
                    title="Throughput"
                    value="342 req/s"
                    data={data.application?.throughput || { labels: [], datasets: [] }}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Error Rates</CardTitle>
                <CardDescription>Application errors and exceptions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <MetricChart
                    title="Error Rate"
                    value="0.8%"
                    status="success"
                    data={data.application?.errorRate || { labels: [], datasets: [] }}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="custom">
          <div className="flex flex-col items-center justify-center p-6 text-center bg-white rounded-lg shadow-sm">
            <span className="material-icons text-4xl text-gray-400 mb-2">add_chart</span>
            <h3 className="text-lg font-medium text-gray-700 mb-2">Create Custom Metrics</h3>
            <p className="text-sm text-gray-500 max-w-md mb-4">
              You can create custom metrics dashboards by selecting specific metrics and visualization types.
            </p>
            <Button>Create New Dashboard</Button>
          </div>
        </TabsContent>
      </Tabs>
    </>
  );
};

export default Metrics;
