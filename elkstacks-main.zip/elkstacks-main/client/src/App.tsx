import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/layout/Sidebar";
import { MobileHeader } from "@/components/layout/MobileHeader";
import Dashboard from "@/pages/Dashboard";
import Metrics from "@/pages/Metrics";
import Logs from "@/pages/Logs";
import Alerts from "@/pages/Alerts";
import Hosts from "@/pages/Hosts";
import NotFound from "@/pages/not-found";
import { useSidebar, SidebarProvider } from "./context/SidebarContext";
import React from "react";

function Layout({ children }: { children: React.ReactNode }) {
  const { closeMobileMenu } = useSidebar();
  const [location] = useLocation();

  // Close mobile menu when location changes
  React.useEffect(() => {
    closeMobileMenu();
  }, [location, closeMobileMenu]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <MobileHeader />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 bg-background">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

function Router() {
  return (
    <SidebarProvider>
      <Layout>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/metrics" component={Metrics} />
          <Route path="/logs" component={Logs} />
          <Route path="/alerts" component={Alerts} />
          <Route path="/hosts" component={Hosts} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
