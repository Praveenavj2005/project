import { Log, Alert, Host, Metric, Service } from "@shared/schema";

// Status type for system components
export type StatusType = "success" | "warning" | "error" | "inactive";

// Time range for metrics and logs
export type TimeRange = "1h" | "3h" | "12h" | "24h" | "3d" | "7d" | "30d" | "custom";

// System overview stats
export interface SystemStatus {
  status: StatusType;
  lastChecked: string;
}

export interface CpuStatus {
  usage: number;
  status: StatusType;
  message?: string;
}

export interface MemoryStatus {
  usage: number;
  total: number;
  used: number;
  status: StatusType;
  message?: string;
}

export interface AlertsStatus {
  count: number;
  status: StatusType;
  latestMessage?: string;
}

// Chart data structure
export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    borderColor: string;
    backgroundColor: string;
    fill?: boolean;
  }[];
}

// Extended log with UI properties
export interface UILog extends Log {
  icon?: string;
  colorClass?: string;
}

// Extended alert with UI properties
export interface UIAlert extends Alert {
  colorClass?: string;
  timeAgo?: string;
}

// Extended host with UI properties
export interface UIHost extends Host {
  statusColor?: string;
}

// Extended service with UI properties
export interface UIService extends Service {
  statusColor?: string;
}

// Dashboard overview data
export interface DashboardData {
  systemStatus: SystemStatus;
  cpuStatus: CpuStatus;
  memoryStatus: MemoryStatus;
  alertsStatus: AlertsStatus;
  recentLogs: UILog[];
  activeAlerts: UIAlert[];
  hosts: UIHost[];
  services: UIService[];
  metrics: {
    cpu: ChartData;
    memory: ChartData;
    disk: ChartData;
    network: ChartData;
  };
}
