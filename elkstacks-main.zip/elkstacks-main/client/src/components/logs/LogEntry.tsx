import React from "react";
import { UILog } from "@/types";
import { format } from "date-fns";

interface LogEntryProps {
  log: UILog;
}

export const LogEntry: React.FC<LogEntryProps> = ({ log }) => {
  // Format the timestamp
  const formattedTimestamp = React.useMemo(() => {
    if (!log.timestamp) return "";
    const date = new Date(log.timestamp);
    return format(date, "yyyy-MM-dd HH:mm:ss");
  }, [log.timestamp]);

  // Determine the icon and color class based on log level
  const getLogLevelDetails = (level: string) => {
    switch (level.toLowerCase()) {
      case "error":
        return {
          icon: "error",
          colorClass: "log-error",
          textClass: "text-status-error",
          label: "[ERROR]",
        };
      case "warning":
        return {
          icon: "warning",
          colorClass: "log-warning",
          textClass: "text-status-warning",
          label: "[WARNING]",
        };
      case "info":
      default:
        return {
          icon: "info",
          colorClass: "log-info",
          textClass: "text-secondary",
          label: "[INFO]",
        };
    }
  };

  const { icon, colorClass, textClass, label } = getLogLevelDetails(log.level);

  return (
    <div className={`log-entry ${colorClass}`}>
      <div className="flex items-start">
        <span className={`material-icons ${textClass} mr-2 text-sm`}>{icon}</span>
        <div className="flex-1">
          <div className="flex justify-between">
            <span className={`${textClass} font-medium`}>{label}</span>
            <span className="text-gray-500 text-xs">{formattedTimestamp}</span>
          </div>
          <div>
            <span>{log.source}: {log.message}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
