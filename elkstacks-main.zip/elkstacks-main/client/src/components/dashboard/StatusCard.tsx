import React from "react";
import { StatusType } from "@/types";

interface StatusCardProps {
  title: string;
  value: string | number;
  icon: string;
  status: StatusType;
  description?: string;
}

export const StatusCard: React.FC<StatusCardProps> = ({
  title,
  value,
  icon,
  status,
  description,
}) => {
  // Map status to color classes
  const statusColorMap = {
    success: "border-status-success",
    warning: "border-status-warning",
    error: "border-status-error",
    inactive: "border-status-inactive",
  };

  const bgColorMap = {
    success: "bg-status-success bg-opacity-10",
    warning: "bg-status-warning bg-opacity-10",
    error: "bg-status-error bg-opacity-10",
    inactive: "bg-status-inactive bg-opacity-10",
  };

  const textColorMap = {
    success: "text-status-success",
    warning: "text-status-warning",
    error: "text-status-error",
    inactive: "text-status-inactive",
  };
  
  const gradientMap = {
    success: "from-status-success to-green-400",
    warning: "from-status-warning to-amber-400",
    error: "from-status-error to-red-400",
    inactive: "from-status-inactive to-gray-400",
  };

  return (
    <div className={`bg-card rounded-lg shadow-md p-5 border-l-4 ${statusColorMap[status]} hover:shadow-lg transition-shadow`}>
      <div className="flex justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="mt-1 text-xl font-bold text-foreground">{value}</h3>
        </div>
        <div className={`rounded-full ${bgColorMap[status]} p-2.5 flex items-center justify-center`}>
          <span className={`material-icons ${textColorMap[status]}`}>{icon}</span>
        </div>
      </div>
      {description && (
        <p className={`mt-2 text-xs font-medium ${status !== 'success' ? textColorMap[status] : 'text-muted-foreground'}`}>
          {description}
        </p>
      )}
      <div className="mt-3 pt-3 border-t border-border">
        <div className="w-full bg-muted rounded-full h-1.5">
          <div 
            className={`h-1.5 rounded-full bg-gradient-to-r ${gradientMap[status]}`}
            style={{ 
              width: status === 'success' ? '100%' : 
                     status === 'warning' ? '60%' : 
                     status === 'error' ? '30%' : '0%' 
            }}
          ></div>
        </div>
      </div>
    </div>
  );
};
