import React from "react";
import { LogEntry } from "@/components/logs/LogEntry";
import { UILog } from "@/types";
import { Input } from "@/components/ui/input";

interface LogsPanelProps {
  logs: UILog[];
}

export const LogsPanel: React.FC<LogsPanelProps> = ({ logs }) => {
  const [searchTerm, setSearchTerm] = React.useState("");

  const filteredLogs = logs.filter(
    (log) =>
      log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.level.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
        <h2 className="text-lg font-medium text-gray-900">Recent Logs</h2>
        <div className="flex items-center">
          <div className="relative mr-2 flex-1">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <span className="material-icons text-gray-400 text-sm">search</span>
            </div>
            <Input
              type="text"
              placeholder="Search logs..."
              className="pl-10 pr-3 py-1.5"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex space-x-2">
            <button 
              className="p-1 hover:bg-gray-100 rounded" 
              aria-label="Filter"
            >
              <span className="material-icons text-gray-500">filter_list</span>
            </button>
            <button 
              className="p-1 hover:bg-gray-100 rounded" 
              aria-label="More options"
            >
              <span className="material-icons text-gray-500">more_vert</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="overflow-hidden">
        <div className="overflow-x-auto">
          <div className="min-w-full">
            {filteredLogs.length > 0 ? (
              filteredLogs.map((log, index) => (
                <LogEntry key={index} log={log} />
              ))
            ) : (
              <div className="p-4 text-center text-gray-500">
                No logs found matching your search criteria.
              </div>
            )}
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-200">
          <a 
            href="/logs" 
            className="text-sm text-primary font-medium hover:text-primary-dark flex items-center"
          >
            View all logs
            <span className="material-icons text-sm ml-1">arrow_forward</span>
          </a>
        </div>
      </div>
    </div>
  );
};
