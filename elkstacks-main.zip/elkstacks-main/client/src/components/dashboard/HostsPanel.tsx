import React from "react";
import { UIHost } from "@/types";

interface HostsPanelProps {
  hosts: UIHost[];
}

export const HostsPanel: React.FC<HostsPanelProps> = ({ hosts }) => {
  return (
    <div className="bg-white rounded-lg shadow mb-6">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Hosts Status</h2>
      </div>
      
      <div className="p-4">
        {hosts.length > 0 ? (
          hosts.map((host, index) => (
            <div 
              key={index} 
              className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-md"
            >
              <div className="flex items-center">
                <span 
                  className={`w-3 h-3 ${host.statusColor} rounded-full mr-3`}
                  aria-hidden="true"
                ></span>
                <span className="text-sm font-medium text-gray-700">{host.name}</span>
              </div>
              <div className="text-sm text-gray-500">{host.ip}</div>
            </div>
          ))
        ) : (
          <div className="p-4 text-center text-gray-500">
            No hosts available.
          </div>
        )}
      </div>
      
      <div className="p-4 border-t border-gray-200">
        <a 
          href="/hosts" 
          className="text-sm text-primary font-medium hover:text-primary-dark flex items-center"
        >
          View all hosts
          <span className="material-icons text-sm ml-1">arrow_forward</span>
        </a>
      </div>
    </div>
  );
};
