import React from "react";
import { Chart } from "@/components/ui/chart";
import { ChartData } from "@/types";

interface MetricsPanelProps {
  cpuData: ChartData;
  memoryData: ChartData;
  diskData: ChartData;
  networkData: ChartData;
  cpuUsage: number;
  memoryUsage: number;
  diskIORate: string;
  networkRate: string;
}

export const MetricsPanel: React.FC<MetricsPanelProps> = ({
  cpuData,
  memoryData,
  diskData,
  networkData,
  cpuUsage,
  memoryUsage,
  diskIORate,
  networkRate,
}) => {
  // Status color classes based on usage
  const getCpuStatusClass = (value: number) => {
    if (value >= 90) return "text-status-error";
    if (value >= 75) return "text-status-warning";
    return "text-status-success";
  };

  const getMemoryStatusClass = (value: number) => {
    if (value >= 90) return "text-status-error";
    if (value >= 75) return "text-status-warning";
    return "text-status-success";
  };

  return (
    <div className="bg-white rounded-lg shadow mb-6">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-lg font-medium text-gray-900">System Metrics</h2>
        <div className="flex space-x-2">
          <button className="p-1 hover:bg-gray-100 rounded" aria-label="Fullscreen">
            <span className="material-icons text-gray-500">fullscreen</span>
          </button>
          <button className="p-1 hover:bg-gray-100 rounded" aria-label="More options">
            <span className="material-icons text-gray-500">more_vert</span>
          </button>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex flex-wrap -mx-2">
          <div className="w-full md:w-1/2 px-2 mb-4">
            <div className="chart-container">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700">CPU Utilization</h3>
                <span className={`text-sm font-medium ${getCpuStatusClass(cpuUsage)}`}>
                  {cpuUsage}%
                </span>
              </div>
              <Chart data={cpuData} />
            </div>
          </div>
          <div className="w-full md:w-1/2 px-2 mb-4">
            <div className="chart-container">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700">Memory Usage</h3>
                <span className={`text-sm font-medium ${getMemoryStatusClass(memoryUsage)}`}>
                  {memoryUsage}%
                </span>
              </div>
              <Chart data={memoryData} />
            </div>
          </div>
          <div className="w-full md:w-1/2 px-2 mb-4">
            <div className="chart-container">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700">Disk I/O</h3>
                <span className="text-sm text-gray-500 font-medium">{diskIORate}</span>
              </div>
              <Chart data={diskData} />
            </div>
          </div>
          <div className="w-full md:w-1/2 px-2 mb-4">
            <div className="chart-container">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-gray-700">Network Traffic</h3>
                <span className="text-sm text-gray-500 font-medium">{networkRate}</span>
              </div>
              <Chart data={networkData} />
            </div>
          </div>
        </div>
        
        <div className="mt-4">
          <a
            href="/metrics"
            className="text-sm text-primary font-medium hover:text-primary-dark flex items-center"
          >
            View all metrics
            <span className="material-icons text-sm ml-1">arrow_forward</span>
          </a>
        </div>
      </div>
    </div>
  );
};
