import React from "react";
import { UIAlert } from "@/types";
import { Button } from "@/components/ui/button";

interface AlertsPanelProps {
  alerts: UIAlert[];
}

export const AlertsPanel: React.FC<AlertsPanelProps> = ({ alerts }) => {
  return (
    <div className="bg-white rounded-lg shadow mb-6">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-lg font-medium text-gray-900">Active Alerts</h2>
        <div className="bg-status-error text-white text-xs px-2 py-1 rounded-full">
          {alerts.length}
        </div>
      </div>
      
      <div className="p-2">
        {alerts.length > 0 ? (
          alerts.map((alert, index) => (
            <div 
              key={index} 
              className={`p-3 border-l-4 ${alert.colorClass} rounded-r-md ${
                alert.level === 'error' ? 'bg-red-50' : 
                alert.level === 'warning' ? 'bg-yellow-50' : 
                'bg-blue-50'
              } mb-2`}
            >
              <div className="flex justify-between">
                <h3 className={`text-sm font-medium ${
                  alert.level === 'error' ? 'text-status-error' : 
                  alert.level === 'warning' ? 'text-status-warning' : 
                  'text-secondary'
                }`}>
                  {alert.level === 'error' ? 'Critical: ' : 
                   alert.level === 'warning' ? 'Warning: ' : 'Info: '}
                  {alert.source}
                </h3>
                <span className="text-xs text-gray-500">{alert.timeAgo}</span>
              </div>
              <p className="mt-1 text-xs text-gray-700">{alert.message}</p>
              <div className="mt-2 flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-7 px-2 py-1 text-xs"
                >
                  Acknowledge
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-7 px-2 py-1 text-xs"
                >
                  Details
                </Button>
              </div>
            </div>
          ))
        ) : (
          <div className="p-4 text-center text-gray-500">
            No active alerts at this time.
          </div>
        )}
      </div>
      
      <div className="p-4 border-t border-gray-200">
        <a 
          href="/alerts" 
          className="text-sm text-primary font-medium hover:text-primary-dark flex items-center"
        >
          Manage alert rules
          <span className="material-icons text-sm ml-1">settings</span>
        </a>
      </div>
    </div>
  );
};
