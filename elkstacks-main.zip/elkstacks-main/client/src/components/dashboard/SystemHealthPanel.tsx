import React from "react";
import { UIService } from "@/types";

interface SystemHealthPanelProps {
  services: UIService[];
}

export const SystemHealthPanel: React.FC<SystemHealthPanelProps> = ({ services }) => {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Monitoring Services</h2>
      </div>
      
      <div className="p-4">
        {services.length > 0 ? (
          services.map((service, index) => (
            <div key={index} className="mb-4">
              <div className="flex justify-between items-center mb-1">
                <h3 className="text-sm font-medium text-gray-700">{service.name}</h3>
                <span 
                  className={`text-xs ${
                    service.status === 'healthy' ? 'text-status-success' : 
                    service.status === 'degraded' ? 'text-status-warning' : 
                    'text-status-error'
                  }`}
                >
                  {service.status === 'healthy' ? 'Healthy' : 
                   service.status === 'degraded' ? 'Degraded' : 
                   'Down'}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`${
                    service.status === 'healthy' ? 'bg-status-success' : 
                    service.status === 'degraded' ? 'bg-status-warning' : 
                    'bg-status-error'
                  } h-2 rounded-full`} 
                  style={{ width: `${service.uptime}%` }}
                ></div>
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-xs text-gray-500">{service.instances} {service.instances === 1 ? 'instance' : 'instances'}</span>
                <span className="text-xs text-gray-500">{service.uptime}% uptime</span>
              </div>
            </div>
          ))
        ) : (
          <div className="p-4 text-center text-gray-500">
            No monitoring services available.
          </div>
        )}
      </div>
    </div>
  );
};
