import React from "react";
import { Link, useLocation } from "wouter";
import { useSidebar } from "@/context/SidebarContext";

export const Sidebar: React.FC = () => {
  const { isCollapsed, toggleSidebar } = useSidebar();
  const [location] = useLocation();

  // Navigation item active state
  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <div 
      className={`hidden md:flex flex-col bg-sidebar border-r border-sidebar-border transition-all shadow-sm ${
        isCollapsed ? "md:w-20" : "md:w-64"
      }`}
    >
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        <h1 className={`text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent ${isCollapsed ? "hidden" : ""}`}>
          MonitorHub
        </h1>
        <button 
          onClick={toggleSidebar} 
          className="p-1 rounded-full hover:bg-sidebar-accent hover:bg-opacity-10 transition-colors"
        >
          <span className="material-icons text-sidebar-foreground">
            {isCollapsed ? "menu" : "menu_open"}
          </span>
        </button>
      </div>
      
      <nav className="flex-1 overflow-y-auto p-4">
        <ul className="space-y-1">
          <li>
            <Link 
              href="/" 
              className={`flex items-center p-2 rounded-md transition-colors ${
                isActive("/") 
                  ? "bg-sidebar-primary bg-opacity-10 text-sidebar-primary font-medium" 
                  : "hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary"
              }`}
            >
              <span className={`material-icons ${isActive("/") ? "text-sidebar-primary" : ""} mr-3`}>dashboard</span>
              <span className={isCollapsed ? "hidden" : ""}>Dashboard</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/metrics" 
              className={`flex items-center p-2 rounded-md transition-colors ${
                isActive("/metrics") 
                  ? "bg-sidebar-primary bg-opacity-10 text-sidebar-primary font-medium" 
                  : "hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary"
              }`}
            >
              <span className={`material-icons ${isActive("/metrics") ? "text-sidebar-primary" : ""} mr-3`}>insert_chart</span>
              <span className={isCollapsed ? "hidden" : ""}>Metrics</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/logs" 
              className={`flex items-center p-2 rounded-md transition-colors ${
                isActive("/logs") 
                  ? "bg-sidebar-primary bg-opacity-10 text-sidebar-primary font-medium" 
                  : "hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary"
              }`}
            >
              <span className={`material-icons ${isActive("/logs") ? "text-sidebar-primary" : ""} mr-3`}>subject</span>
              <span className={isCollapsed ? "hidden" : ""}>Logs</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/alerts" 
              className={`flex items-center p-2 rounded-md transition-colors ${
                isActive("/alerts") 
                  ? "bg-sidebar-primary bg-opacity-10 text-sidebar-primary font-medium" 
                  : "hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary"
              }`}
            >
              <span className={`material-icons ${isActive("/alerts") ? "text-sidebar-primary" : ""} mr-3`}>notifications</span>
              <span className={isCollapsed ? "hidden" : ""}>Alerts</span>
              <span className={`ml-auto bg-status-error text-white text-xs px-1.5 py-0.5 rounded-full ${isCollapsed ? "hidden" : ""}`}>
                3
              </span>
            </Link>
          </li>
          <li>
            <Link 
              href="/hosts" 
              className={`flex items-center p-2 rounded-md transition-colors ${
                isActive("/hosts") 
                  ? "bg-sidebar-primary bg-opacity-10 text-sidebar-primary font-medium" 
                  : "hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary"
              }`}
            >
              <span className={`material-icons ${isActive("/hosts") ? "text-sidebar-primary" : ""} mr-3`}>dns</span>
              <span className={isCollapsed ? "hidden" : ""}>Hosts</span>
            </Link>
          </li>
        </ul>
        
        <div className={`mt-8 ${isCollapsed ? "hidden" : ""}`}>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
            Integrations
          </h3>
          <ul className="space-y-1">
            <li>
              <a 
                href="#elasticsearch" 
                className="flex items-center p-2 rounded-md hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary transition-colors"
              >
                <span className="material-icons mr-3">storage</span>
                <span className={isCollapsed ? "hidden" : ""}>Elasticsearch</span>
              </a>
            </li>
            <li>
              <a 
                href="#logstash" 
                className="flex items-center p-2 rounded-md hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary transition-colors"
              >
                <span className="material-icons mr-3">input</span>
                <span className={isCollapsed ? "hidden" : ""}>Logstash</span>
              </a>
            </li>
            <li>
              <a 
                href="#kibana" 
                className="flex items-center p-2 rounded-md hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary transition-colors"
              >
                <span className="material-icons mr-3">analytics</span>
                <span className={isCollapsed ? "hidden" : ""}>Kibana</span>
              </a>
            </li>
            <li>
              <a 
                href="#prometheus" 
                className="flex items-center p-2 rounded-md hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary transition-colors"
              >
                <span className="material-icons mr-3">monitor</span>
                <span className={isCollapsed ? "hidden" : ""}>Prometheus</span>
              </a>
            </li>
          </ul>
        </div>
      </nav>
      
      <div className={`p-4 border-t border-sidebar-border ${isCollapsed ? "hidden" : ""}`}>
        <a 
          href="#settings" 
          className="flex items-center p-2 rounded-md hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary transition-colors"
        >
          <span className="material-icons mr-3">settings</span>
          <span className={isCollapsed ? "hidden" : ""}>Settings</span>
        </a>
        <a 
          href="#help" 
          className="flex items-center p-2 rounded-md hover:bg-muted text-sidebar-foreground hover:text-sidebar-primary transition-colors"
        >
          <span className="material-icons mr-3">help</span>
          <span className={isCollapsed ? "hidden" : ""}>Help & Docs</span>
        </a>
      </div>
    </div>
  );
};
