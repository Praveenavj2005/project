import React from "react";
import { Link, useLocation } from "wouter";
import { useSidebar } from "@/context/SidebarContext";

export const MobileHeader: React.FC = () => {
  const { isMobileMenuOpen, toggleMobileMenu } = useSidebar();
  const [location] = useLocation();
  
  // Navigation item active state
  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <header className="bg-card border-b border-border md:hidden">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center">
          <button 
            onClick={toggleMobileMenu}
            className="p-1 mr-2 rounded-full hover:bg-muted"
            aria-label="Toggle mobile menu"
          >
            <span className="material-icons text-foreground">menu</span>
          </button>
          <h1 className="text-lg font-semibold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            MonitorHub
          </h1>
        </div>
        <div className="flex items-center">
          <button className="p-2 relative" aria-label="Notifications">
            <span className="material-icons text-foreground">notifications</span>
            <span className="alert-badge">3</span>
          </button>
          <button className="p-2" aria-label="Account">
            <span className="material-icons text-foreground">account_circle</span>
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation Menu (toggle visibility) */}
      <div className={isMobileMenuOpen ? "bg-card border-b border-border shadow-sm" : "hidden"}>
        <nav className="p-4">
          <ul>
            <li className="mb-2">
              <Link 
                href="/" 
                className={`flex items-center p-2 rounded-md ${
                  isActive("/") 
                    ? "bg-primary bg-opacity-10 text-primary font-medium" 
                    : "hover:bg-muted text-foreground"
                }`}
              >
                <span className="material-icons mr-3">dashboard</span>
                Dashboard
              </Link>
            </li>
            <li className="mb-2">
              <Link 
                href="/metrics" 
                className={`flex items-center p-2 rounded-md ${
                  isActive("/metrics") 
                    ? "bg-primary bg-opacity-10 text-primary font-medium" 
                    : "hover:bg-muted text-foreground"
                }`}
              >
                <span className="material-icons mr-3">insert_chart</span>
                Metrics
              </Link>
            </li>
            <li className="mb-2">
              <Link 
                href="/logs" 
                className={`flex items-center p-2 rounded-md ${
                  isActive("/logs") 
                    ? "bg-primary bg-opacity-10 text-primary font-medium" 
                    : "hover:bg-muted text-foreground"
                }`}
              >
                <span className="material-icons mr-3">subject</span>
                Logs
              </Link>
            </li>
            <li className="mb-2">
              <Link 
                href="/alerts" 
                className={`flex items-center p-2 rounded-md ${
                  isActive("/alerts") 
                    ? "bg-primary bg-opacity-10 text-primary font-medium" 
                    : "hover:bg-muted text-foreground"
                }`}
              >
                <span className="material-icons mr-3">notifications</span>
                Alerts
                <span className="ml-auto bg-status-error text-white text-xs px-1.5 py-0.5 rounded-full">
                  3
                </span>
              </Link>
            </li>
            <li className="mb-2">
              <Link 
                href="/hosts" 
                className={`flex items-center p-2 rounded-md ${
                  isActive("/hosts") 
                    ? "bg-primary bg-opacity-10 text-primary font-medium" 
                    : "hover:bg-muted text-foreground"
                }`}
              >
                <span className="material-icons mr-3">dns</span>
                Hosts
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};
