import React from "react";
import { Chart } from "@/components/ui/chart";
import { ChartData, StatusType } from "@/types";

interface MetricChartProps {
  title: string;
  value: string | number;
  unit?: string;
  status?: StatusType;
  data: ChartData;
  height?: number;
}

export const MetricChart: React.FC<MetricChartProps> = ({
  title,
  value,
  unit,
  status = "success",
  data,
  height = 200,
}) => {
  // Status color classes based on status
  const getStatusClass = (status: StatusType) => {
    switch (status) {
      case "error":
        return "text-status-error";
      case "warning":
        return "text-status-warning";
      case "success":
        return "text-status-success";
      default:
        return "text-gray-500";
    }
  };

  return (
    <div className="chart-container" style={{ height }}>
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-medium text-gray-700">{title}</h3>
        <span className={`text-sm font-medium ${getStatusClass(status)}`}>
          {value}{unit && unit}
        </span>
      </div>
      <Chart data={data} height={height - 30} />
    </div>
  );
};
