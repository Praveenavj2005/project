import * as React from "react";
import { Line, Bar, Pie, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  BarElement,
  ArcElement,
} from "chart.js";
import { cn } from "@/lib/utils";
import { ChartData } from "@/types";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  BarElement,
  ArcElement
);

// Default chart options
const defaultLineOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false,
    },
    tooltip: {
      mode: "index",
      intersect: false,
    },
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
    },
    y: {
      beginAtZero: true,
      grid: {
        color: "rgba(0, 0, 0, 0.05)",
      },
      ticks: {
        precision: 0,
      },
    },
  },
  elements: {
    line: {
      tension: 0.3,
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
    },
  },
};

const defaultBarOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false,
    },
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
    },
    y: {
      beginAtZero: true,
      grid: {
        color: "rgba(0, 0, 0, 0.05)",
      },
    },
  },
};

const defaultPieOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "bottom" as const,
      labels: {
        padding: 20,
        boxWidth: 10,
      },
    },
  },
};

type ChartType = "line" | "bar" | "pie" | "doughnut";

export interface ChartProps
  extends React.HTMLAttributes<HTMLDivElement> {
  data: ChartData;
  type?: ChartType;
  options?: any;
  height?: number;
}

const Chart = React.forwardRef<HTMLDivElement, ChartProps>(
  ({ data, type = "line", options = {}, height = 200, className, ...props }, ref) => {
    // Merge options with defaults based on chart type
    const chartOptions = React.useMemo(() => {
      if (type === "line") {
        return { ...defaultLineOptions, ...options };
      } else if (type === "bar") {
        return { ...defaultBarOptions, ...options };
      } else if (type === "pie" || type === "doughnut") {
        return { ...defaultPieOptions, ...options };
      }
      return options;
    }, [type, options]);

    const renderChart = () => {
      switch (type) {
        case "line":
          return <Line data={data} options={chartOptions} />;
        case "bar":
          return <Bar data={data} options={chartOptions} />;
        case "pie":
          return <Pie data={data} options={chartOptions} />;
        case "doughnut":
          return <Doughnut data={data} options={chartOptions} />;
        default:
          return <Line data={data} options={chartOptions} />;
      }
    };

    return (
      <div
        ref={ref}
        className={cn("chart-container", className)}
        style={{ height }}
        {...props}
      >
        {renderChart()}
      </div>
    );
  }
);

Chart.displayName = "Chart";

export { Chart };
