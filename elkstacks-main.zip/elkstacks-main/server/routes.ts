import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupDashboardRoutes } from "./api/dashboard";
import { setupMetricsRoutes } from "./api/metrics";
import { setupLogsRoutes } from "./api/logs";
import { setupAlertsRoutes } from "./api/alerts";
import { setupHostsRoutes } from "./api/hosts";
import { setupHealthRoutes } from "./api/health";
import { initializeStorage } from "./services/elasticsearch";
import { initializePrometheus } from "./services/prometheus";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize mock data in storage
  await initializeStorage();
  await initializePrometheus();

  // Setup API routes
  app.use('/api/dashboard', setupDashboardRoutes());
  app.use('/api/metrics', setupMetricsRoutes());  
  app.use('/api/logs', setupLogsRoutes());
  app.use('/api/alerts', setupAlertsRoutes());
  app.use('/api/hosts', setupHostsRoutes());
  app.use('/api/health', setupHealthRoutes());

  const httpServer = createServer(app);

  return httpServer;
}
