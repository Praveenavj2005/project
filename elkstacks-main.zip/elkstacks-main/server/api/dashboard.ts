import express from "express";
import { storage } from "../storage";
import { getTimeRangeFilter } from "../services/elasticsearch";
import { getRandomMetricData } from "../services/prometheus";

export function setupDashboardRoutes() {
  const router = express.Router();

  // Get dashboard overview data
  router.get("/", async (req, res) => {
    try {
      const timeRange = req.query.timeRange as string || "24h";
      const timeFilter = getTimeRangeFilter(timeRange);
      
      // Get system status
      const systemStatus = {
        status: "success" as const,
        lastChecked: "2 minutes ago"
      };
      
      // Get CPU status
      const cpuStatus = {
        usage: 78,
        status: "warning" as const,
        message: "Approaching high usage"
      };
      
      // Get memory status
      const memoryStatus = {
        usage: 42,
        total: 16,
        used: 6.5,
        status: "success" as const
      };
      
      // Get alerts status
      const alerts = await storage.getAlerts(timeFilter);
      const activeAlerts = alerts.filter(alert => !alert.acknowledged && !alert.resolved);
      
      const alertsStatus = {
        count: activeAlerts.length,
        status: activeAlerts.length > 0 ? "error" as const : "success" as const,
        latestMessage: activeAlerts.length > 0 
          ? activeAlerts[0].message 
          : undefined
      };
      
      // Get recent logs with formatting for UI
      const logs = await storage.getRecentLogs(timeFilter, 5);
      
      // Get hosts with status
      const hosts = await storage.getHosts();
      
      // Get services health
      const services = await storage.getServices();
      
      // Generate chart data for metrics
      const timeLabels = [...Array(24)].map((_, i) => `${i}:00`);
      
      const metrics = {
        cpu: getRandomMetricData(timeLabels, 20, 90, "CPU Utilization"),
        memory: getRandomMetricData(timeLabels, 30, 60, "Memory Usage"),
        disk: getRandomMetricData(timeLabels, 10, 40, "Disk I/O"),
        network: getRandomMetricData(timeLabels, 2, 8, "Network Traffic")
      };
      
      res.json({
        systemStatus,
        cpuStatus,
        memoryStatus,
        alertsStatus,
        recentLogs: logs,
        activeAlerts,
        hosts,
        services,
        metrics
      });
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  return router;
}
