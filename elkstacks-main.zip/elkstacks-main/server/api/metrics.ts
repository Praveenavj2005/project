import express from "express";
import { storage } from "../storage";
import { getTimeRangeFilter } from "../services/prometheus";

export function setupMetricsRoutes() {
  const router = express.Router();

  // Get metrics data for detailed metrics page
  router.get("/", async (req, res) => {
    try {
      const timeRange = req.query.timeRange as string || "24h";
      const tab = req.query.activeTab as string || "system";
      
      const timeFilter = getTimeRangeFilter(timeRange);
      
      // Get filtered metrics based on timeRange
      const metricsData = await storage.getMetricsData(timeFilter, tab);

      res.json(metricsData);
    } catch (error) {
      console.error("Error fetching metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics data" });
    }
  });

  // Get specific metric by name
  router.get("/:name", async (req, res) => {
    try {
      const { name } = req.params;
      const timeRange = req.query.timeRange as string || "24h";
      
      const timeFilter = getTimeRangeFilter(timeRange);
      
      const metricData = await storage.getMetricByName(name, timeFilter);
      
      if (!metricData) {
        return res.status(404).json({ message: `Metric '${name}' not found` });
      }
      
      res.json(metricData);
    } catch (error) {
      console.error(`Error fetching metric '${req.params.name}':`, error);
      res.status(500).json({ message: "Failed to fetch metric data" });
    }
  });

  return router;
}
