import express from "express";
import { storage } from "../storage";

export function setupHostsRoutes() {
  const router = express.Router();

  // Get all hosts with metrics
  router.get("/", async (req, res) => {
    try {
      const hosts = await storage.getHosts();
      
      // Get host metrics for all hosts
      const metrics: Record<string, any> = {};
      
      for (const host of hosts) {
        metrics[host.id] = {
          cpu: {
            data: await storage.getHostMetric(host.id, "cpu"),
            current: Math.floor(Math.random() * 40) + 40 // Random value between 40-80%
          },
          memory: {
            data: await storage.getHostMetric(host.id, "memory"),
            current: Math.floor(Math.random() * 30) + 30 // Random value between 30-60%
          },
          disk: {
            data: await storage.getHostMetric(host.id, "disk"),
            current: Math.floor(Math.random() * 50) + 40 // Random value between 40-90%
          }
        };
      }
      
      res.json({
        hosts,
        metrics
      });
    } catch (error) {
      console.error("Error fetching hosts:", error);
      res.status(500).json({ message: "Failed to fetch hosts data" });
    }
  });

  // Get host by ID
  router.get("/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const hostId = parseInt(id);
      
      if (isNaN(hostId)) {
        return res.status(400).json({ message: "Invalid host ID" });
      }
      
      const host = await storage.getHost(hostId);
      
      if (!host) {
        return res.status(404).json({ message: `Host with ID ${id} not found` });
      }
      
      // Get host metrics
      const metrics = {
        cpu: await storage.getHostMetric(hostId, "cpu"),
        memory: await storage.getHostMetric(hostId, "memory"),
        disk: await storage.getHostMetric(hostId, "disk")
      };
      
      res.json({
        host,
        metrics
      });
    } catch (error) {
      console.error(`Error fetching host '${req.params.id}':`, error);
      res.status(500).json({ message: "Failed to fetch host data" });
    }
  });

  return router;
}
