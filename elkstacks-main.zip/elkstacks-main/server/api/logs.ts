import express from "express";
import { storage } from "../storage";
import { getTimeRangeFilter } from "../services/elasticsearch";

export function setupLogsRoutes() {
  const router = express.Router();

  // Get logs with filtering and pagination
  router.get("/", async (req, res) => {
    try {
      const search = req.query.debouncedSearch as string || "";
      const level = req.query.levelFilter as string || "all";
      const source = req.query.sourceFilter as string || "all";
      const timeRange = req.query.timeRange as string || "24h";
      const page = parseInt(req.query.page as string || "1");
      const pageSize = 10; // Fixed page size

      const timeFilter = getTimeRangeFilter(timeRange);
      
      // Get filtered and paginated logs
      const result = await storage.searchLogs({
        search,
        level: level !== "all" ? level : undefined,
        source: source !== "all" ? source : undefined,
        timeFilter,
        page,
        pageSize
      });

      // Format response
      res.json({
        logs: result.logs,
        totalCount: result.totalCount,
        page,
        pageSize,
        totalPages: Math.ceil(result.totalCount / pageSize)
      });
    } catch (error) {
      console.error("Error fetching logs:", error);
      res.status(500).json({ message: "Failed to fetch logs data" });
    }
  });

  // Get log by ID
  router.get("/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const logId = parseInt(id);
      
      if (isNaN(logId)) {
        return res.status(400).json({ message: "Invalid log ID" });
      }
      
      const log = await storage.getLog(logId);
      
      if (!log) {
        return res.status(404).json({ message: `Log with ID ${id} not found` });
      }
      
      res.json(log);
    } catch (error) {
      console.error(`Error fetching log '${req.params.id}':`, error);
      res.status(500).json({ message: "Failed to fetch log data" });
    }
  });

  return router;
}
