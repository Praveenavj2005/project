import express from "express";
import { storage } from "../storage";
import { getTimeRangeFilter } from "../services/elasticsearch";

export function setupAlertsRoutes() {
  const router = express.Router();

  // Get alerts with filtering by status
  router.get("/", async (req, res) => {
    try {
      const timeRange = req.query.timeRange as string || "24h";
      const activeTab = req.query.activeTab as string || "active";
      
      const timeFilter = getTimeRangeFilter(timeRange);
      
      // Get all alerts within the time range
      const allAlerts = await storage.getAlerts(timeFilter);
      
      // Filter alerts based on the requested tab
      const active = allAlerts.filter(alert => !alert.acknowledged && !alert.resolved);
      const acknowledged = allAlerts.filter(alert => alert.acknowledged && !alert.resolved);
      const resolved = allAlerts.filter(alert => alert.resolved);
      
      res.json({
        active,
        acknowledged,
        resolved,
        activeCount: active.length,
        acknowledgedCount: acknowledged.length,
        resolvedCount: resolved.length
      });
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts data" });
    }
  });

  // Acknowledge an alert
  router.post("/:id/acknowledge", async (req, res) => {
    try {
      const { id } = req.params;
      const alertId = parseInt(id);
      
      if (isNaN(alertId)) {
        return res.status(400).json({ message: "Invalid alert ID" });
      }
      
      const alert = await storage.getAlert(alertId);
      
      if (!alert) {
        return res.status(404).json({ message: `Alert with ID ${id} not found` });
      }
      
      // Update alert to acknowledged
      const updatedAlert = await storage.acknowledgeAlert(alertId);
      
      res.json(updatedAlert);
    } catch (error) {
      console.error(`Error acknowledging alert '${req.params.id}':`, error);
      res.status(500).json({ message: "Failed to acknowledge alert" });
    }
  });

  // Resolve an alert
  router.post("/:id/resolve", async (req, res) => {
    try {
      const { id } = req.params;
      const alertId = parseInt(id);
      
      if (isNaN(alertId)) {
        return res.status(400).json({ message: "Invalid alert ID" });
      }
      
      const alert = await storage.getAlert(alertId);
      
      if (!alert) {
        return res.status(404).json({ message: `Alert with ID ${id} not found` });
      }
      
      // Update alert to resolved
      const updatedAlert = await storage.resolveAlert(alertId);
      
      res.json(updatedAlert);
    } catch (error) {
      console.error(`Error resolving alert '${req.params.id}':`, error);
      res.status(500).json({ message: "Failed to resolve alert" });
    }
  });

  return router;
}
