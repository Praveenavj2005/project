import express from "express";
import { storage } from "../storage";

export function setupHealthRoutes() {
  const router = express.Router();

  // Get health status of monitoring services
  router.get("/", async (req, res) => {
    try {
      const services = await storage.getServices();
      
      const healthStatus = {
        elasticsearch: services.find(s => s.name === "Elasticsearch"),
        logstash: services.find(s => s.name === "Logstash"),
        kibana: services.find(s => s.name === "Kibana"),
        prometheus: services.find(s => s.name === "Prometheus")
      };
      
      res.json(healthStatus);
    } catch (error) {
      console.error("Error fetching health status:", error);
      res.status(500).json({ message: "Failed to fetch health status" });
    }
  });

  // Get health status for a specific service
  router.get("/:service", async (req, res) => {
    try {
      const { service } = req.params;
      const services = await storage.getServices();
      
      const serviceHealth = services.find(s => 
        s.name.toLowerCase() === service.toLowerCase()
      );
      
      if (!serviceHealth) {
        return res.status(404).json({ message: `Service '${service}' not found` });
      }
      
      res.json(serviceHealth);
    } catch (error) {
      console.error(`Error fetching health for service '${req.params.service}':`, error);
      res.status(500).json({ message: "Failed to fetch service health" });
    }
  });

  return router;
}
