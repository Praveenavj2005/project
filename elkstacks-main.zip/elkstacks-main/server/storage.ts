import { 
  users, 
  type User, 
  type InsertUser, 
  logs, 
  type Log, 
  type InsertLog, 
  alerts, 
  type Alert, 
  type InsertAlert, 
  hosts, 
  type Host, 
  type InsertHost, 
  metrics, 
  type Metric, 
  type InsertMetric, 
  services, 
  type Service, 
  type InsertService 
} from "@shared/schema";
import { UILog, UIAlert, UIHost, UIService, StatusType } from "@/types";
import { format, formatDistanceToNow } from "date-fns";
import { getRandomMetricData } from "./services/prometheus";

// Define the time filter interface
interface TimeFilter {
  startTime: Date;
  endTime: Date;
}

// Define the logs search params interface
interface LogsSearchParams {
  search?: string;
  level?: string;
  source?: string;
  timeFilter: TimeFilter;
  page: number;
  pageSize: number;
}

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Log methods
  getLogs(): Promise<Log[]>;
  getLog(id: number): Promise<Log | undefined>;
  getRecentLogs(timeFilter: TimeFilter, limit: number): Promise<UILog[]>;
  searchLogs(params: LogsSearchParams): Promise<{ logs: UILog[], totalCount: number }>;
  createLog(log: InsertLog): Promise<Log>;
  
  // Alert methods
  getAlerts(timeFilter: TimeFilter): Promise<UIAlert[]>;
  getAlert(id: number): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  acknowledgeAlert(id: number): Promise<Alert>;
  resolveAlert(id: number): Promise<Alert>;
  
  // Host methods
  getHosts(): Promise<UIHost[]>;
  getHost(id: number): Promise<Host | undefined>;
  createHost(host: InsertHost): Promise<Host>;
  
  // Metric methods
  getMetrics(timeFilter: TimeFilter): Promise<Metric[]>;
  getMetricByName(name: string, timeFilter: TimeFilter): Promise<Metric[]>;
  getMetricsData(timeFilter: TimeFilter, tab: string): Promise<any>;
  createMetric(metric: InsertMetric): Promise<Metric>;
  getHostMetric(hostId: number, metricType: string): Promise<any>;
  
  // Service methods
  getServices(): Promise<UIService[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private logs: Map<number, Log>;
  private alerts: Map<number, Alert>;
  private hosts: Map<number, Host>;
  private metrics: Map<number, Metric>;
  private services: Map<number, Service>;
  
  currentUserId: number;
  currentLogId: number;
  currentAlertId: number;
  currentHostId: number;
  currentMetricId: number;
  currentServiceId: number;

  constructor() {
    this.users = new Map();
    this.logs = new Map();
    this.alerts = new Map();
    this.hosts = new Map();
    this.metrics = new Map();
    this.services = new Map();
    
    this.currentUserId = 1;
    this.currentLogId = 1;
    this.currentAlertId = 1;
    this.currentHostId = 1;
    this.currentMetricId = 1;
    this.currentServiceId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Log methods
  async getLogs(): Promise<Log[]> {
    return Array.from(this.logs.values()).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }
  
  async getLog(id: number): Promise<Log | undefined> {
    return this.logs.get(id);
  }
  
  async getRecentLogs(timeFilter: TimeFilter, limit: number): Promise<UILog[]> {
    const allLogs = await this.getLogs();
    
    const filteredLogs = allLogs.filter(log => {
      const logDate = new Date(log.timestamp);
      return logDate >= timeFilter.startTime && logDate <= timeFilter.endTime;
    });
    
    // Get the most recent logs up to the limit
    const recentLogs = filteredLogs.slice(0, limit);
    
    // Transform logs to UILogs
    return recentLogs.map(log => this.formatLogForUI(log));
  }
  
  async searchLogs(params: LogsSearchParams): Promise<{ logs: UILog[], totalCount: number }> {
    const { search, level, source, timeFilter, page, pageSize } = params;
    const allLogs = await this.getLogs();
    
    // Filter logs based on search, level, source, and time range
    const filteredLogs = allLogs.filter(log => {
      // Time filter
      const logDate = new Date(log.timestamp);
      const inTimeRange = logDate >= timeFilter.startTime && logDate <= timeFilter.endTime;
      
      if (!inTimeRange) return false;
      
      // Search filter
      const matchesSearch = !search || 
        log.message.toLowerCase().includes(search.toLowerCase()) || 
        log.source.toLowerCase().includes(search.toLowerCase()) ||
        log.level.toLowerCase().includes(search.toLowerCase());
      
      if (!matchesSearch) return false;
      
      // Level filter
      const matchesLevel = !level || log.level === level;
      
      if (!matchesLevel) return false;
      
      // Source filter
      const matchesSource = !source || log.source === source;
      
      return matchesSource;
    });
    
    // Calculate pagination
    const totalCount = filteredLogs.length;
    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    const paginatedLogs = filteredLogs.slice(start, end);
    
    // Transform logs to UILogs
    const uiLogs = paginatedLogs.map(log => this.formatLogForUI(log));
    
    return {
      logs: uiLogs,
      totalCount
    };
  }
  
  async createLog(insertLog: InsertLog): Promise<Log> {
    const id = this.currentLogId++;
    const log: Log = { 
      ...insertLog, 
      id,
      timestamp: insertLog.timestamp || new Date(),
      metadata: insertLog.metadata || {}
    };
    this.logs.set(id, log);
    return log;
  }
  
  // Helper method to format a log for UI display
  private formatLogForUI(log: Log): UILog {
    // Determine icon and color class based on log level
    let icon = "info";
    let colorClass = "log-info";
    
    if (log.level === "error") {
      icon = "error";
      colorClass = "log-error";
    } else if (log.level === "warning") {
      icon = "warning";
      colorClass = "log-warning";
    }
    
    return {
      ...log,
      icon,
      colorClass
    };
  }
  
  // Alert methods
  async getAlerts(timeFilter: TimeFilter): Promise<UIAlert[]> {
    const allAlerts = Array.from(this.alerts.values()).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    
    // Filter alerts by time range
    const filteredAlerts = allAlerts.filter(alert => {
      const alertDate = new Date(alert.timestamp);
      return alertDate >= timeFilter.startTime && alertDate <= timeFilter.endTime;
    });
    
    // Transform alerts to UIAlerts
    return filteredAlerts.map(alert => this.formatAlertForUI(alert));
  }
  
  async getAlert(id: number): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }
  
  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentAlertId++;
    const alert: Alert = { 
      ...insertAlert, 
      id,
      timestamp: insertAlert.timestamp || new Date(),
      acknowledged: insertAlert.acknowledged !== undefined ? insertAlert.acknowledged : false,
      resolved: insertAlert.resolved !== undefined ? insertAlert.resolved : false
    };
    this.alerts.set(id, alert);
    return alert;
  }
  
  async acknowledgeAlert(id: number): Promise<Alert> {
    const alert = await this.getAlert(id);
    
    if (!alert) {
      throw new Error(`Alert with ID ${id} not found`);
    }
    
    const updatedAlert = {
      ...alert,
      acknowledged: true
    };
    
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }
  
  async resolveAlert(id: number): Promise<Alert> {
    const alert = await this.getAlert(id);
    
    if (!alert) {
      throw new Error(`Alert with ID ${id} not found`);
    }
    
    const updatedAlert = {
      ...alert,
      resolved: true
    };
    
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }
  
  // Helper method to format an alert for UI display
  private formatAlertForUI(alert: Alert): UIAlert {
    // Determine color class based on alert level
    let colorClass = "border-secondary";
    
    if (alert.level === "error") {
      colorClass = "border-status-error";
    } else if (alert.level === "warning") {
      colorClass = "border-status-warning";
    }
    
    // Calculate time ago
    const timeAgo = formatDistanceToNow(new Date(alert.timestamp), { addSuffix: true });
    
    return {
      ...alert,
      colorClass,
      timeAgo
    };
  }
  
  // Host methods
  async getHosts(): Promise<UIHost[]> {
    const allHosts = Array.from(this.hosts.values());
    
    // Transform hosts to UIHosts
    return allHosts.map(host => this.formatHostForUI(host));
  }
  
  async getHost(id: number): Promise<Host | undefined> {
    return this.hosts.get(id);
  }
  
  async createHost(insertHost: InsertHost): Promise<Host> {
    const id = this.currentHostId++;
    const host: Host = { 
      ...insertHost, 
      id,
      metadata: insertHost.metadata || {}
    };
    this.hosts.set(id, host);
    return host;
  }
  
  // Helper method to format a host for UI display
  private formatHostForUI(host: Host): UIHost {
    // Determine status color based on host status
    let statusColor = "bg-status-inactive";
    
    if (host.status === "healthy") {
      statusColor = "bg-status-success";
    } else if (host.status === "warning") {
      statusColor = "bg-status-warning";
    } else if (host.status === "error") {
      statusColor = "bg-status-error";
    }
    
    return {
      ...host,
      statusColor
    };
  }
  
  // Metric methods
  async getMetrics(timeFilter: TimeFilter): Promise<Metric[]> {
    const allMetrics = Array.from(this.metrics.values()).sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    // Filter metrics by time range
    return allMetrics.filter(metric => {
      const metricDate = new Date(metric.timestamp);
      return metricDate >= timeFilter.startTime && metricDate <= timeFilter.endTime;
    });
  }
  
  async getMetricByName(name: string, timeFilter: TimeFilter): Promise<Metric[]> {
    const allMetrics = await this.getMetrics(timeFilter);
    
    // Filter metrics by name
    return allMetrics.filter(metric => metric.name === name);
  }
  
  async getMetricsData(timeFilter: TimeFilter, tab: string): Promise<any> {
    // Generate time labels for the chart data
    const timeLabels = generateTimeLabels(timeFilter);
    
    // Create a base response with all sections initialized to ensure they exist
    const response = {
      cpu: {
        utilization: getRandomMetricData(timeLabels, 50, 90, "CPU Utilization"),
        temperature: getRandomMetricData(timeLabels, 40, 70, "CPU Temperature"),
        loadAverage: getRandomMetricData(timeLabels, 0, 8, "Load Average"),
        cores: getRandomMetricData(timeLabels, 30, 100, "Core Usage")
      },
      memory: {
        usage: getRandomMetricData(timeLabels, 30, 60, "RAM Usage"),
        swap: getRandomMetricData(timeLabels, 0, 30, "Swap Usage"),
        allocated: getRandomMetricData(timeLabels, 40, 80, "Allocated Memory")
      },
      disk: {
        usage: getRandomMetricData(timeLabels, 40, 80, "Disk Usage"),
        iops: getRandomMetricData(timeLabels, 100, 500, "IOPS"),
        throughput: getRandomMetricData(timeLabels, 5, 40, "Throughput")
      },
      network: {
        traffic: getRandomMetricData(timeLabels, 2, 10, "Network Traffic"),
        packets: getRandomMetricData(timeLabels, 1000, 5000, "Packets/s"),
        errors: getRandomMetricData(timeLabels, 0, 1, "Error Rate")
      },
      application: {
        responseTime: getRandomMetricData(timeLabels, 100, 300, "Response Time"),
        throughput: getRandomMetricData(timeLabels, 200, 500, "Requests/s"),
        errorRate: getRandomMetricData(timeLabels, 0, 2, "Error Rate")
      }
    };

    // Return the full response regardless of tab selection
    // Frontend can decide which sections to display based on the active tab
    return response;
  }
  
  async createMetric(insertMetric: InsertMetric): Promise<Metric> {
    const id = this.currentMetricId++;
    const metric: Metric = { 
      ...insertMetric, 
      id,
      timestamp: insertMetric.timestamp || new Date(),
      metadata: insertMetric.metadata || {}
    };
    this.metrics.set(id, metric);
    return metric;
  }
  
  async getHostMetric(hostId: number, metricType: string): Promise<any> {
    // Generate time labels for the last 24 hours
    const timeLabels = [...Array(24)].map((_, i) => `${i}:00`);
    
    // Generate random data for the host metric
    let min = 0;
    let max = 0;
    let label = "";
    
    switch (metricType) {
      case "cpu":
        min = 20;
        max = 80;
        label = "CPU Usage";
        break;
      case "memory":
        min = 20;
        max = 70;
        label = "Memory Usage";
        break;
      case "disk":
        min = 30;
        max = 90;
        label = "Disk Usage";
        break;
      default:
        min = 0;
        max = 100;
        label = "Usage";
    }
    
    return getRandomMetricData(timeLabels, min, max, label);
  }
  
  // Service methods
  async getServices(): Promise<UIService[]> {
    const allServices = Array.from(this.services.values());
    
    // Transform services to UIServices
    return allServices.map(service => this.formatServiceForUI(service));
  }
  
  async getService(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }
  
  async createService(insertService: InsertService): Promise<Service> {
    const id = this.currentServiceId++;
    const service: Service = { 
      ...insertService, 
      id,
      lastChecked: insertService.lastChecked || new Date()
    };
    this.services.set(id, service);
    return service;
  }
  
  // Helper method to format a service for UI display
  private formatServiceForUI(service: Service): UIService {
    // Determine status color based on service status
    let statusColor = "bg-status-inactive";
    
    if (service.status === "healthy") {
      statusColor = "bg-status-success";
    } else if (service.status === "degraded") {
      statusColor = "bg-status-warning";
    } else if (service.status === "down") {
      statusColor = "bg-status-error";
    }
    
    return {
      ...service,
      statusColor
    };
  }
}

// Helper function to generate time labels based on time filter
function generateTimeLabels(timeFilter: TimeFilter): string[] {
  const { startTime, endTime } = timeFilter;
  const duration = endTime.getTime() - startTime.getTime();
  const hours = duration / (60 * 60 * 1000);
  
  // For time periods under 24 hours, show hourly labels
  if (hours <= 24) {
    return [...Array(Math.ceil(hours))].map((_, i) => {
      const date = new Date(startTime.getTime() + i * 60 * 60 * 1000);
      return format(date, 'HH:mm');
    });
  }
  
  // For periods over 24 hours but under 7 days, show daily labels
  if (hours <= 168) {
    const days = Math.ceil(hours / 24);
    return [...Array(days)].map((_, i) => {
      const date = new Date(startTime.getTime() + i * 24 * 60 * 60 * 1000);
      return format(date, 'MM/dd');
    });
  }
  
  // For longer periods, show weekly labels
  const weeks = Math.ceil(hours / (24 * 7));
  return [...Array(weeks)].map((_, i) => {
    const date = new Date(startTime.getTime() + i * 7 * 24 * 60 * 60 * 1000);
    return format(date, 'MM/dd');
  });
}

export const storage = new MemStorage();
