import { storage } from "../storage";
import { InsertLog, InsertAlert, InsertHost, InsertService } from "@shared/schema";

// Initialize storage with mock data for ELK stack components
export async function initializeStorage() {
  console.log("Initializing ELK stack mock data...");
  
  // Create mock logs
  const mockLogs: InsertLog[] = [
    {
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      level: "error",
      source: "db-server-2",
      message: "Disk usage exceeded 90% threshold. Current: 92%",
      metadata: { ip: "10.0.1.5", severity: "high" }
    },
    {
      timestamp: new Date(Date.now() - 20 * 60 * 1000),
      level: "warning",
      source: "app-server-1",
      message: "High CPU utilization detected (78%)",
      metadata: { ip: "10.0.1.4", severity: "medium" }
    },
    {
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      level: "info",
      source: "logstash",
      message: "Logstash pipeline restarted successfully",
      metadata: { ip: "10.0.1.6", severity: "low" }
    },
    {
      timestamp: new Date(Date.now() - 32 * 60 * 1000),
      level: "info",
      source: "elasticsearch",
      message: "Elasticsearch index rotation completed",
      metadata: { ip: "10.0.1.7", severity: "low" }
    },
    {
      timestamp: new Date(Date.now() - 35 * 60 * 1000),
      level: "info",
      source: "prometheus",
      message: "Prometheus scrape completed: 128 targets, 0 errors",
      metadata: { ip: "10.0.1.8", severity: "low" }
    },
    {
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      level: "error",
      source: "api-gateway",
      message: "Service unavailable, 5 attempts failed",
      metadata: { ip: "10.0.1.7", severity: "high" }
    },
    {
      timestamp: new Date(Date.now() - 50 * 60 * 1000),
      level: "warning",
      source: "cache-server-1",
      message: "Cache miss rate above threshold (25%)",
      metadata: { ip: "10.0.1.9", severity: "medium" }
    },
    {
      timestamp: new Date(Date.now() - 55 * 60 * 1000),
      level: "info",
      source: "web-server-1",
      message: "Nginx configuration reloaded",
      metadata: { ip: "10.0.1.8", severity: "low" }
    },
    {
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      level: "info",
      source: "kibana",
      message: "New dashboard created by admin user",
      metadata: { ip: "10.0.1.10", severity: "low" }
    },
    {
      timestamp: new Date(Date.now() - 70 * 60 * 1000),
      level: "warning",
      source: "db-server-1",
      message: "Slow query detected (duration: 5.2s)",
      metadata: { ip: "10.0.1.11", severity: "medium" }
    }
  ];
  
  // Create mock alerts
  const mockAlerts: InsertAlert[] = [
    {
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      level: "error",
      source: "Disk Space",
      message: "db-server-2: Disk usage at 92%, threshold 90%",
      acknowledged: false,
      resolved: false
    },
    {
      timestamp: new Date(Date.now() - 32 * 60 * 1000),
      level: "error",
      source: "Service Down",
      message: "api-gateway: Service unavailable, 5 attempts failed",
      acknowledged: false,
      resolved: false
    },
    {
      timestamp: new Date(Date.now() - 43 * 60 * 1000),
      level: "warning",
      source: "High CPU",
      message: "app-server-1: CPU usage at 78%, threshold 75%",
      acknowledged: false,
      resolved: false
    },
    {
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      level: "warning",
      source: "Memory Usage",
      message: "web-server-1: Memory usage at, 82%, threshold 80%",
      acknowledged: true,
      resolved: false
    },
    {
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      level: "error",
      source: "Database Error",
      message: "db-server-1: Connection pool exhausted",
      acknowledged: true,
      resolved: false
    },
    {
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      level: "info",
      source: "Certificate Expiry",
      message: "web-server-1: SSL certificate expires in 10 days",
      acknowledged: false,
      resolved: true
    },
    {
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
      level: "warning",
      source: "Disk Space",
      message: "app-server-1: Disk usage at 85%, threshold 80%",
      acknowledged: false,
      resolved: true
    },
    {
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      level: "error",
      source: "Network Error",
      message: "Load balancer: Unable to reach backend servers",
      acknowledged: true,
      resolved: true
    }
  ];
  
  // Create mock hosts
  const mockHosts: InsertHost[] = [
    {
      name: "app-server-1",
      ip: "10.0.1.4",
      status: "warning",
      metadata: {
        os: "Ubuntu 20.04 LTS",
        kernel: "5.4.0-89-generic",
        cpu: "Intel Xeon E5-2680 v4 @ 2.40GHz (8 cores)",
        memory: "16 GB",
        uptime: "15 days, 7 hours"
      }
    },
    {
      name: "db-server-2",
      ip: "10.0.1.5",
      status: "error",
      metadata: {
        os: "CentOS 8.4",
        kernel: "4.18.0-305.el8.x86_64",
        cpu: "AMD EPYC 7302 @ 3.00GHz (16 cores)",
        memory: "64 GB",
        uptime: "23 days, 12 hours"
      }
    },
    {
      name: "cache-server-1",
      ip: "10.0.1.6",
      status: "healthy",
      metadata: {
        os: "Amazon Linux 2",
        kernel: "4.14.231-173.361.amzn2.x86_64",
        cpu: "Intel Xeon E5-2686 v4 @ 2.30GHz (4 cores)",
        memory: "8 GB",
        uptime: "30 days, 5 hours"
      }
    },
    {
      name: "api-gateway",
      ip: "10.0.1.7",
      status: "error",
      metadata: {
        os: "Debian 11",
        kernel: "5.10.0-8-amd64",
        cpu: "Intel Xeon E5-2650 v4 @ 2.20GHz (4 cores)",
        memory: "8 GB",
        uptime: "2 days, 9 hours"
      }
    },
    {
      name: "web-server-1",
      ip: "10.0.1.8",
      status: "healthy",
      metadata: {
        os: "Ubuntu 20.04 LTS",
        kernel: "5.4.0-89-generic",
        cpu: "Intel Xeon E5-2680 v4 @ 2.40GHz (4 cores)",
        memory: "8 GB",
        uptime: "45 days, 3 hours"
      }
    }
  ];
  
  // Create mock services
  const mockServices: InsertService[] = [
    {
      name: "Elasticsearch",
      status: "healthy",
      uptime: 92,
      instances: 3,
      lastChecked: new Date()
    },
    {
      name: "Logstash",
      status: "healthy",
      uptime: 100,
      instances: 2,
      lastChecked: new Date()
    },
    {
      name: "Kibana",
      status: "healthy",
      uptime: 97,
      instances: 1,
      lastChecked: new Date()
    },
    {
      name: "Prometheus",
      status: "degraded",
      uptime: 78,
      instances: 1,
      lastChecked: new Date()
    }
  ];
  
  // Insert all mock data
  for (const log of mockLogs) {
    await storage.createLog(log);
  }
  
  for (const alert of mockAlerts) {
    await storage.createAlert(alert);
  }
  
  for (const host of mockHosts) {
    await storage.createHost(host);
  }
  
  for (const service of mockServices) {
    await storage.createService(service);
  }
  
  console.log("Initialization of ELK stack data complete.");
}

// Helper function to get time range filter for Elasticsearch queries
export function getTimeRangeFilter(timeRange: string) {
  const now = new Date();
  let startTime: Date;
  
  switch (timeRange) {
    case '1h':
      startTime = new Date(now.getTime() - 1 * 60 * 60 * 1000);
      break;
    case '3h':
      startTime = new Date(now.getTime() - 3 * 60 * 60 * 1000);
      break;
    case '12h':
      startTime = new Date(now.getTime() - 12 * 60 * 60 * 1000);
      break;
    case '3d':
      startTime = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
      break;
    case '7d':
      startTime = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case '30d':
      startTime = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      break;
    case '24h':
    default:
      startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }
  
  return { startTime, endTime: now };
}
