import { storage } from "../storage";
import { InsertMetric } from "@shared/schema";

// Initialize storage with mock Prometheus metrics
export async function initializePrometheus() {
  console.log("Initializing Prometheus mock metrics...");
  
  // Create timestamp range (last 24 hours with 5-minute intervals)
  const now = new Date();
  const timestamps: Date[] = [];
  
  for (let i = 24 * 12; i >= 0; i--) {
    timestamps.push(new Date(now.getTime() - i * 5 * 60 * 1000));
  }
  
  // Create CPU utilization metrics
  for (const timestamp of timestamps) {
    // CPU Utilization (fluctuating between 50-90%)
    await storage.createMetric({
      timestamp,
      name: "cpu_utilization",
      value: (Math.random() * 30 + 50).toFixed(2), // 50-80%
      source: "system",
      metadata: { unit: "percentage" }
    });
    
    // Memory Usage (fluctuating between 30-60%)
    await storage.createMetric({
      timestamp,
      name: "memory_usage",
      value: (Math.random() * 30 + 30).toFixed(2), // 30-60%
      source: "system",
      metadata: { unit: "percentage" }
    });
    
    // Disk I/O (fluctuating between 10-40 MB/s)
    await storage.createMetric({
      timestamp,
      name: "disk_io",
      value: (Math.random() * 30 + 10).toFixed(2), // 10-40 MB/s
      source: "system",
      metadata: { unit: "MB/s" }
    });
    
    // Network Traffic (fluctuating between 2-8 MB/s)
    await storage.createMetric({
      timestamp,
      name: "network_traffic",
      value: (Math.random() * 6 + 2).toFixed(2), // 2-8 MB/s
      source: "system",
      metadata: { unit: "MB/s" }
    });
    
    // Application Response Time (fluctuating between 100-250ms)
    await storage.createMetric({
      timestamp,
      name: "response_time",
      value: (Math.random() * 150 + 100).toFixed(2), // 100-250ms
      source: "application",
      metadata: { unit: "ms" }
    });
    
    // Application Throughput (requests per second)
    await storage.createMetric({
      timestamp,
      name: "throughput",
      value: (Math.random() * 200 + 200).toFixed(2), // 200-400 req/s
      source: "application",
      metadata: { unit: "req/s" }
    });
    
    // Error Rate (0-2%)
    await storage.createMetric({
      timestamp,
      name: "error_rate",
      value: (Math.random() * 2).toFixed(2), // 0-2%
      source: "application",
      metadata: { unit: "percentage" }
    });
    
    // Create host-specific metrics
    for (let hostId = 1; hostId <= 5; hostId++) {
      // Host CPU
      await storage.createMetric({
        timestamp,
        name: `host_${hostId}_cpu`,
        value: (Math.random() * 40 + 40).toFixed(2), // 40-80%
        source: `host-${hostId}`,
        metadata: { unit: "percentage" }
      });
      
      // Host Memory
      await storage.createMetric({
        timestamp,
        name: `host_${hostId}_memory`,
        value: (Math.random() * 30 + 30).toFixed(2), // 30-60%
        source: `host-${hostId}`,
        metadata: { unit: "percentage" }
      });
      
      // Host Disk
      await storage.createMetric({
        timestamp,
        name: `host_${hostId}_disk`,
        value: (Math.random() * 50 + 40).toFixed(2), // 40-90%
        source: `host-${hostId}`,
        metadata: { unit: "percentage" }
      });
    }
  }
  
  console.log("Initialization of Prometheus metrics complete.");
}

// Helper function to generate random chart data
export function getRandomMetricData(
  labels: string[], 
  min: number, 
  max: number, 
  label: string
) {
  const data = labels.map(() => Math.floor(Math.random() * (max - min)) + min);
  
  return {
    labels: labels,
    datasets: [
      {
        label: label,
        data: data,
        borderColor: "hsl(var(--chart-1))",
        backgroundColor: "rgba(63, 81, 181, 0.1)",
        fill: true
      }
    ]
  };
}

// Helper function to get time range filter for Prometheus queries
export function getTimeRangeFilter(timeRange: string) {
  const now = new Date();
  let startTime: Date;
  
  switch (timeRange) {
    case '1h':
      startTime = new Date(now.getTime() - 1 * 60 * 60 * 1000);
      break;
    case '3h':
      startTime = new Date(now.getTime() - 3 * 60 * 60 * 1000);
      break;
    case '12h':
      startTime = new Date(now.getTime() - 12 * 60 * 60 * 1000);
      break;
    case '3d':
      startTime = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
      break;
    case '7d':
      startTime = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case '30d':
      startTime = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      break;
    case '24h':
    default:
      startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }
  
  return { startTime, endTime: now };
}
